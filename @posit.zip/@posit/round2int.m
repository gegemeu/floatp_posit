function binc=round2int(bina);
%ROUND2INT round the posit to the nearest integer

% dependancies: posit2dec

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(bina);
nbits = bina.nbits;

binc = bina;

for i = 1:na
 for j = 1:ma
  dec = posit2dec(bina(i,j));
  binc(i,j) = posit(round(dec),nbits);
  
 end % for j
end % for i


   
  