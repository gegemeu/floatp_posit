function qc = add_posit_quire(pa,qb);
%ADD_POSIT_QUIRE addition of a posit pa and a quire qb towards a quire

% dependancies: add_quire, posit2quire

% needs the quire class

%
% Author G. Meurant
% May 2020
%

qa = quire(pa);
 
qc = add_quire(qa,qb);



