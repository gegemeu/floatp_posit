function s = dot_prod_positq(pa,pb);
%DOT_PROD_POSITQ dot product of two posit vectors using a quire

% in this function, we convert to quires before doing the product

% this is not the posit "standard" in which there is only one quire

% needs the quire class

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(pa);
[nb,mb] = size(pb);

if na ~= 1 && ma ~= 1 && nb ~= 1 && mb ~= 1
 error(' dot_prod_posit: the inputs must be posit vectors')
end % if

nbitsa = pa(1).nbits;
nbitsb = pb(1).nbits;

if nbitsa ~=  nbitsb
 error(' dot_prod_posit: the input vectors must have the same value of nbits')
end % if

la = length(pa);
lb = length(pb);
if la ~= lb
 error(' p_dot_prod_posit: the two vectors must have the same length')
end % if

 q = quire(0,nbitsa);
 
 for k = 1:la
  qa = quire(pa(k));
  qb = quire(pb(k));
  q = add_quire(mul_quire(qa,qb),q);
 end % for k
 
 s = quire2posit(q);
 
 

 
 