function binx=lu_solver_posit(binb,L,U,p);
%LU_SOLVER_POSIT linear solver for posit linear systems

% L U binx = binb(p)

%
% Author G. Meurant
% April 2020
%

nbits = binb(1).nbits;

binb = binb(p);

% solve L y = binb
n = size(L,1);

y = posit(zeros(n,1),nbits);
y(1) = div_posit(binb(1), L(1,1));

for k = 2:n
 s = dot_posit(L(k,1:k-1), y(1:k-1));
%  y(k) = div_posit(minus_posit(binb(k), s), L(k,k));
 y(k) = minus_posit(binb(k), s); % L(k,k) = 1
end % for k

% solve of U binx = y
binx = posit(zeros(n,1),nbits);
binx(n) = div_posit(y(n), U(n,n));

for k = n-1:-1:1
 s = dot_posit(U(k,k+1:n), binx(k+1:n));
 binx(k) = div_posit(minus_posit(y(k), s), U(k,k));
end % for k

