function binc = rdivide(bina,binb);
%RDIVIDE componentwise division of two posit numbers or matrices

% bina ./ binb

% dependancies: div_posit, div_positm

%
% Author G. Meurant
% May 2020
%

if ~isa(bina,'posit')
 bina = posit(bina,binb(1).nbits);
end % if 

if ~isa(binb,'posit')
 binb = posit(binb,bina(1).nbits);
end % if 

[na,ma] = size(bina);
[nb,mb] = size(binb);

if na == 1 && ma == 1 && nb ~= 1 && mb ~= 1
 binc = binb;
 for i = 1:nb
  for j = 1:mb
   binc(i,j) = div_posit(bina,binb(i,j));
  end % for j
 end % for i
 return
end % if
 
if na ~= nb || nb ~= mb
 error(' rdivide: the two inputs must have the same size')
end % if

if na == 1 && ma == 1 && nb == 1 && mb == 1
 binc = div_posit(bina,binb);
 
else
 binc = div_positm(bina,binb);
end % if



