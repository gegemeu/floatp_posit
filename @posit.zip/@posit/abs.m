function r = abs(p);
%ABS absolute value of the posit 

r = p;
r.sign = 0;
r.float = abs(p.float);



