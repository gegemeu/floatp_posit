function disp(x)
% DISP displays a posit as a double

%
% Author G. Meurant
% May 2020
%

disp(double(x))

