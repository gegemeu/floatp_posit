function binc=ctranspose(bina);
%CTRANSPOSE transpose of a (real) posit matrix

% no dependancies

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;
[na,ma] = size(bina);
binc = posit(zeros(ma,na),nbits);

for i = 1:na
 for j = 1:ma
  binc(j,i) = bina(i,j);
 end % for j
end % for i

