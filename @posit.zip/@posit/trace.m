function binc=trace(bina);
%TRACE trace of a posit matrix

%
% Author G. Meurant
% May 2020
%

d = diag(bina);
binc = sum(d);

