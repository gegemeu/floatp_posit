function printposit(bin)
%PRINTPOSIT prints the fields of a posit

%
% Author G. Meurant
% May 2020

[n,m] = size(bin);

if n == 1 && m == 1
 fprintf(' sign = %d \n',bin.sign)
 fprintf(' regime = %s \n',fix_bin2str(bin.regime))
 fprintf(' exponent = %s \n',fix_bin2str(bin.exponent))
 fprintf(' mantissa = %s \n',fix_bin2str(bin.mantissa))
 fprintf(' float = %12.5e \n',bin.float)
 fprintf(' nbits = %d \n',bin.nbits)
 fprintf(' es = %d \n\n',bin.es)

else
 fprintf('\n %d by %d posit array \n',n,m)
 posit2dec(bin)
 
end % if
