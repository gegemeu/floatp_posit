function r = div_posit(diva,divb);
%DIV_POSIT division of posits diva / divb

% compute an approximation of the inverse of divb and multiply by diva

% dependancies: posit_inv_Newton, mul_posit

%
% Author G. Meurant
% May 2020
%

if iszero_posit(diva) && ~iszero_posit(divb) % 0 / divb
 r = diva;
 return
end % if

if iszero_posit(divb)
 % divb is equal to zero, return Inf
 fprintf(' div_posit: divide by zero \n')
 r = diva;
 r.sign = 1;
 r.regime = zeros(1,length(r.regime));
 r.exponent = zeros(1,length(r.exponent));
 r.mantissa = zeros(1,length(r.mantissa));
 r.float = Inf; % return Inf
 return
end % if

absdivb = divb;
absdivb.sign = 0;

r = posit_inv_Newton(absdivb); % Newton iteration for 1 / abs(divb)

r.sign = divb.sign;
if r.sign == 1
 r.float = -r.float;
end % if

r = mul_posit(r, diva);