function dec = posit2decm(bina);
%POSIT2DECM converts a posit matrix to decimal (double floating point)

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(bina);

dec = zeros(na,ma);

for i = 1:na
 for j = 1:ma
  dec(i,j) = posit2dec(bina(i,j));
 end % for j
end % for i

