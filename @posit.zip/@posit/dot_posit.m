function s = dot_posit(binav,binbv);
%DOT_POSIT dot product of two posit vectors

% the result may not be accurate. If not use quires

% binav and binbv must have the same parameters

% dependancies: mul_posit, add_posit

%
% Author G. Meurant
% March 2020
%

na = length(binav);
nb = length(binbv);
if na ~= nb
 error(' dot_posit: the two binary vectors must have the same length')
end % if

nbitsa = binav.nbits;
nbitsb = binbv.nbits;
if nbitsa ~= nbitsb
 error(' dot_posit: the two binary vectors must have the same parameters')
end % if

s = posit(0,nbitsa); % s = 0

for k = 1:na
 product = mul_posit(binav(k),binbv(k));
 s = add_posit(s,product);
end % for k

