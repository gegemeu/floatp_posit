function x=iszero_binfp(bin);
%ISZERO_BINFP returns true (1) if the floating point binary number is zero

%
% Author G. Meurant
% May 2020
%

x = 0;

I = bin.I;
F = bin.F;

if sum(I) == 0 && sum(F) == 0
 x = 1;
end % if


