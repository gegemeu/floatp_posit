function Z = subsref(X,S)
%SUBSREF for posits

if isequal(S.type,'.')
 Z = X;
else
 nbits = X.nbits;
 Z = posit(subsref(double(X),S),nbits);
end

