function dec = posit2dec(bina);
%POSIT2DEC converts posit to decimal (double floating point)

%
% Author G. Meurant
% May 2020
%

[row,col] = size(bina);
dec = zeros(row,col);

for i = 1:row
 for j = 1:col
  dec(i,j) = p_posit2decimal(bina(i,j));
 end % for j
end % for i

end % function


function dec = p_posit2decimal(bina);

if iszero_posit(bina)
 dec = 0;
 return
end % if

% check if the input is + or - infinity
bin = posit2bin(bina);
if bin(1) == 1
 if ~any(bin(2:end))
  dec = Inf;
  return
 end % if
end % if bin

% compute mantissa
manval = 1; % hidden bit
% it is better to start with the smallest values
% this can be vectorized using p_bin2frac
for i = length(bina.mantissa):-1:1
 manval = manval + bina.mantissa(i) * 2^(-i); 
 % this does not work well if nbits is large because the terms become too small
end % for

% computation of the total exponent

e = [bina.exponent zeros(1,bina.es-length(bina.exponent))]; % pad with zeros

ttotalexp = ((-1)^(bina.regime(1,1) + 1)) * (p_regrunlength(bina.regime)) * 2^bina.es + p_bin2dec(e);

reg = bina.regime;
if length(reg) == 1
 ttotalexp = p_bin2dec(e);
end % if

dec = manval * (2^ttotalexp);

if bina.sign == 1
 dec = -dec;
end % if

end % function





