function binc=ceil(bina);
%CEIL ceil for a posit number

% dependancies: posit2dec

%
% Author G. Meurant
% April 2020
%

[na,ma] = size(bina);
nbits = bina.nbits;

binc = bina;

for i = 1:na
 for j = 1:ma
  dec = posit2dec(binc(i,j));
  binc(i,j) = posit(ceil(dec),nbits);
  
 end % for j
end % for i



