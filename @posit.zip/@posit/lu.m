function [L,U,P,p] = lu(A);
%LU  triangular factorization for posit matrices

% [L,U,P] = lu(A) produces a unit lower triangular matrix L, an upper triangular matrix U,
%  and a permutation vector p, such that L * U = P * A

% p is the permutation vector corresponding to P

n = size(A,1);
p = (1:n)';

nbits = A.nbits;

for k = 1:n-1
 
 % find index of largest element below diagonal in k-th column
 [~,m] = max(abs(posit2decm(A(k:n,k))));
 m = m + k - 1;
 
 % skip elimination if column is zero
 if posit2dec(A(m,k)) ~= 0
  
  % swap pivot row
  if m ~= k
   A([k m],:) = A([m k],:);
   p([k m]) = p([m k]);
  end
  
  % compute multipliers
  i = k+1:n;
  A(i,k) = div_positms(A(i,k), A(k,k)); % division of a vector by a scalar
  
  % update the remainder of the matrix
  j = k+1:n;
  A(i,j) = minus_positm(A(i,j), mul_posito(A(i,k), A(k,j))); % subtraction of an outer product
 end % if
 
end % for k

% separate result
I = posit_eye(nbits,n);
L = add_positm(tril(A,-1), I);
U = triu(A);

% construct P
P = I(:,p);
