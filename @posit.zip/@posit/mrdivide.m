function binc = mrdivide(bina,binb);
%MRDIVIDE  division of two posit numbers or matrices

% bina / binb

% for matrices, binc * binb = bina, binc is a row vector

% dependancies: div_posit, div_positm

%
% Author G. Meurant
% May 2020
%

if ~isa(bina,'posit')
 bina = posit(bina,binb(1).nbits);
end % if 

if ~isa(binb,'posit')
 binb = posit(binb,bina(1).nbits);
end % if 

[na,ma] = size(bina);
[nb,mb] = size(binb);

if na == 1 && ma == 1 && nb == 1 && mb == 1
 binc = div_posit(bina,binb);
 
else
 if nb ~= mb
  error(' mrdivide: binb must be a square matrix')
 end % if
 if ma ~= mb
  error(' mrdivide: incompatible dimensions')
 end % if
 
 binbt = ctranspose(binb);
 binta = ctranspose(bina);
 y = mldivide(binbt, binta);
 binc = ctranspose(y);
 
end % if




