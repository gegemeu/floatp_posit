function bin=right_shift_binfp(bina,k,sig);
%RIGHT_SHIFT_BINFP shift bina to the right by k places

% bina is a nonzero normalized floating point number 1.xxxx... 2^e

% dependancies: p_round_bin

%
% Author G. Meurant
% May 2020
%

k = abs(k); % k must be positive

bin = bina;

if k == 0
 return
end % if

F = [zeros(1,k-1) 1 bin.F];
[F,cnext] = p_round_bin(F,bin.nbits,sig); % round the mantissa to nbits

if cnext == 1
 bin.I = [1];
else
 bin.I = [];
end % if

bin.F = F;
bin.E = bin.E + k;


