function binc=posit2floatp(pa);
%POSIT2FLOATP converts a posit to a floatp structure

%
% Author G. Meurant
% May 2020
%

% compute the total exponent (of 2) for pa
e = [pa.exponent zeros(1,pa.es-length(pa.exponent))]; % pad with zeros

texp = ((-1)^(pa.regime(1,1) + 1)) * (p_regrunlength(pa.regime)) * 2^pa.es + p_bin2dec(e);

nbits = pa.nbits;

binc = struct('sign',0,'I',[],'F',[],'E',[],'float',0,'nbits',nbits);

binc.sign = pa.sign;
binc.I = [1]; % hidden bit
binc.F = pa.mantissa;
binc.E = texp;
binc.float = pa.float;
binc.nbits = nbits;


