function s = sum_abs_posit(p);
%SUM_ABS_POSIT sum of the absolute values of the components of a posit vector using a quire

%
% Author G. Meurant
% May 2020
%

[n,m] = size(p);
if n == 1 && m == 1
 s = abs(p);
 return
end % if

nbits = p(1).nbits;

if (n == 1 && m ~= 1) || (n ~= 1 && m == 1)
 q = quire(0,nbits);
 
 for k =1:max(n,m)
  q = add_posit_quire(abs(p(k)),q);
 end % for k
 
 s = quire2posit(q);
 
 return
 
end % if
 
error(' sum_posit: the input must be a posit vector')
 
 