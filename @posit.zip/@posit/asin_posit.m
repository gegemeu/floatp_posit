function binc=asin_posit(bina);
%ASIN_POSIT inverse sine function for a posit number

% dependancies: posit2dec, add_posit, mul_posit, div_posit

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;

dec = posit2dec(bina);

if abs(dec) > 1
 error(' asin_posit: the argument must have an absolute value less than or equal to 1')
end % if

if abs(dec) < 2^(-nbits)
 binc = posit(0,nbits);
 return
end % if

if abs(dec - 1) < 2^(-nbits)
 binc = posit(pi/2,nbits);
 return
end % if

if abs(dec + 1) < 2^(-nbits)
 binc = posit(-pi/2,nbits);
 return
end % if

if abs(dec) < 2^(-nbits/2)
 binc = bina;
 return
end % if

pS0 = posit(1.66666666666666657415e-01,nbits);
pS1 = posit(-3.25565818622400915405e-01,nbits);
pS2 = posit(2.01212532134862925881e-01,nbits);
pS3 = posit(-4.00555345006794114027e-02,nbits);
pS4 = posit(7.91534994289814532176e-04,nbits);
pS5 = posit(3.47933107596021167570e-05,nbits);
qS1 = posit(-2.40339491173441421878e+00,nbits);
qS2 = posit(2.02094576023350569471e+00,nbits);
qS3 = posit(-6.88283971605453293030e-01,nbits);
qS4 = posit(7.70381505559019352791e-02,nbits);

one = posit(1,nbits);
pis2 = posit(pi/2,nbits);
two = posit(2,nbits);

if abs(dec) < 0.5
 
 t = mul_posit(bina, bina);
 p = mul_posit(t, add_posit(pS0, mul_posit(t, add_posit(pS1, mul_posit(t, add_posit(pS2, mul_posit(t,...
  add_posit(pS3, mul_posit(t, add_posit(pS4, mul_posit(t, pS5)))))))))));
 q = add_posit(one, mul_posit(t, add_posit(qS1, mul_posit(t, add_posit(qS2, mul_posit(t, add_posit(qS3, mul_posit(t, qS4))))))));
 w = div_posit(p, q);
 binc =  add_posit(bina, mul_posit(bina, w));
 return
 
else
 w = minus_posit(one, abs(bina));
 t = mul_posit(w, posit(0.5,nbits));
 p = mul_posit(t, add_posit(pS0, mul_posit(t, add_posit(pS1, mul_posit(t, add_posit(pS2,...
  mul_posit(t, add_posit(pS3, mul_posit(t, add_posit(pS4, mul_posit(t, pS5)))))))))));
 q =  add_posit(one, mul_posit(t, add_posit(qS1, mul_posit(t, add_posit(qS2, mul_posit(t, add_posit(qS3, mul_posit(t, qS4))))))));
 s = sqrt_posit(t);
 
 if abs(dec) > 0.975
  w = div_posit(p, q);
  t = minus_posit(pis2, mul_posit(two, add_posit(s, mul_posit(s, w))));
  
 else
  w  = s;
  c  = div_posit(minus(t, mul_posit(w, w)) , add_posit(s, w));
  r  = div_posit(p, q);
  t = minus_posit(pis2, mul_posit(two,  add_posit(minus_posit(mul_posit(s, r), c), w)));
 end % if
 
 binc = t;
 if dec < 0
  binc.sign = 1;
 end % if
 
end % if

