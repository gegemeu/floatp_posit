function binc=floor(bina);
%FLOOR floor for a posit number

% No dependancies

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(bina);
nbits = bina.nbits;

binc = bina;

for i = 1:na
 for j = 1:ma
  dec = posit2dec(bina(i,j));
  binc(i,j) = posit(floor(dec),nbits);
  
 end % for j
end % for i



