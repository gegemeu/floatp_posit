function binc = cos(bina);
%COS componentwise cosine of a posit number or matrix

% input in radians

% dependancies: cos_posit

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(bina);

if na == 1 && ma == 1
 binc = cos_posit(bina);
 
else
 binc = bina;
 [na,ma] = size(bina);
 for i = 1:na
  for j = 1:ma
   binc(i,j) = cos_posit(bina(i,j));
  end % for j
 end % for j
 
end % if



