function binc = mat_prod_posit(bina,binb);
%MAT_PROD_POSIT matrix-matrix product for posits

% inputs are assumed to have compatible dimensions

% dependancies: mul_posit

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(bina);
[nb,mb] = size(binb);

nbits = min(bina(1,1).nbits,binb(1,1).nbits);

% ma must be equal to na

binc = posit(zeros(na,mb),nbits);

for i = 1:na
 for j = 1:mb
  s = posit(0,nbits);
  
  for k = 1:ma
   s = add_posit(s, mul_posit(bina(i,k), binb(k,j)));
  end % for k
  
  binc(i,j) = s;
  
 end % for j
end % for i

