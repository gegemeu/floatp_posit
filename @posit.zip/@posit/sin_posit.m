function binc=sin_posit(bina);
%SIN_POSIT sine function for a posit number

% dependancies: posit2dec, round2int, add_posit, mul_posit, floor

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;

dec = posit2dec(bina);
dec = abs(dec);
dec = mod(dec,2*pi);

if dec <= 2^(-nbits)
 binc = posit(0,nbits);
 return
end % if

if abs(dec - pi/2) <= 2^(-nbits) 
 binc = posit(1,nbits);
 return
end % if

if abs(dec - 3*pi/2) <= 2^(-nbits)
 binc = posit(-1,nbits);
 return
end % if

if abs(dec - pi) <= 2^(-nbits)
 binc = posit(0,nbits);
 return
end % if

% convert dec back to binary fixed point 
if bina.sign == 1
 dec = -dec;
end % if
bina = posit(dec,nbits);


pi1 = posit(0.31830988618379067154,nbits); % 1 / pi

sigp = bina.sign;
if sigp == 0
 sig = 1;
else
 sig = -1;
end % if

y = abs(bina);
n = round2int(mul_posit(y,pi1));

x1 = floor(y); 
x2 = minus_posit(y,x1);
c1 = posit(3217 / 1024,nbits);
c2 = posit(-8.908910206761537356617e-6,nbits);

f = minus_posit( add_posit( minus_posit(x1, mul_posit(n,c1)), x2), mul_posit(n,c2)); % ( (x1 - n * c1) + x2) - n * c2

s1 = posit(-1.66666666666666324348e-01,nbits);
s2 = posit(8.33333333332248946124e-03,nbits);
s3 = posit(-1.98412698298579493134e-04,nbits);
s4 = posit(2.75573137070700676789e-06,nbits);
s5 = posit(-2.50507602534068634195e-08,nbits);
s6 = posit(1.58969099521155010221e-10,nbits);

if posit2dec(bina) == 0
 binc = posit(0,nbits);
 return
end % if

fd = posit2dec(f);
if abs(fd) > 2^(-32)
 
 z = mul_posit(f,f);
 v =  mul_posit(z,f);
 r =  add_posit(s2, mul_posit(z, add_posit(s3, mul_posit(z, add_posit(s4, mul_posit(z, add_posit(s5, mul_posit(z,s6)))))))); % r =  s2 + z * (s3 + z * (s4 + z * (s5 + z * s6)))
 binc = add_posit(f, mul_posit(v ,(add_posit(s1, mul_posit(z,r))))); % s = f + v * (s1 + z * r)
 
else
 
 binc = f;
 
end % if

if sig ~= 1
 binc.sign = ~f.sign;
 binc.float = -binc.float;
else
 binc.sign = f.sign;
end % if

if mod(n.float,2) ~= 0
 binc.sign = ~binc.sign;
 binc.float = -binc.float;
end % if


