function binc=log_posit(bina);
%LOG_POSIT natural logarithm of a posit number

% dependancies: posit2dec, add_posit, mul_posit

%
% Author G. Meurant
% May 2020
%

if bina.sign == 1
 error(' log_posit: bina must be a positive number')
end % if

nbits = bina.nbits;

ln2 = posit(0.69314718055994528622676398299518,nbits); % log(2)

dec = posit2dec(bina);
pow = log2(dec);
if abs(2^pow - dec) <= eps
 binc = mul_posit( posit(pow,nbits), ln2);
 return
end % if

Lg1 = posit(6.666666666666735130e-01,nbits);
Lg2 = posit(3.999999999940941908e-01,nbits);
Lg3 = posit(2.857142874366239149e-01,nbits);
Lg4 = posit(2.222219843214978396e-01,nbits);
Lg5 = posit(1.818357216161805012e-01,nbits);
Lg6 = posit(1.531383769920937332e-01,nbits);
Lg7 = posit(1.479819860511658591e-01,nbits);

% ln2_hi = 355 / 512;
% ln2_lo = -2.121944400546905827679e-4; % ln2_hi + ln2_lo = log(2)

[fd,ed] = log2(dec);
f = posit(fd,nbits);
e = posit(ed,nbits);
one = posit(1,nbits);
f = minus_posit(f,one);
hfsq = mul_posit(f, mul_posit(f, posit(0.5,nbits)));

two = posit(2,nbits);
s = div_posit(f, add_posit(f,two));
z = mul_posit(s,s);
w = mul_posit(z,z);
t1 = mul_posit(w, add_posit(Lg2, mul_posit(w, add_posit(Lg4, mul_posit(w,Lg6) ))));
t2 = mul_posit(z, add_posit(Lg1, mul_posit(w, add_posit(Lg3, mul_posit(w, add_posit(Lg5, mul_posit(w,Lg7) ))))));
R = add_posit(t2,t1);

if ed == 0 
 binc = minus_posit(f, minus_posit(hfsq, mul_posit(s, add_posit(hfsq, R))) ); 
%  l = f - s * (f - R); 
else
% l = e * ln2_hi - ((hfsq - (s * (hfsq + R) + e * ln2_lo )) - f);
binc = minus_posit( mul_posit(e,ln2), minus_posit( minus_posit(hfsq, mul_posit(s, add_posit(hfsq, R) ) ), f));
% l = e * ln2 - ((s * (f - R) ) - f);
end % if


