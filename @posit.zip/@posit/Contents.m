% @POSIT
%
% Files
%   abs               - absolute value of the posit 
%   acos              - componentwise inverse cosine of posit numbers or matrix
%   acos_posit        - inverse cosine function for a positt number
%   acot              - componentwise inverse tangent of a binary floating point number or matrix
%   acot_posit        - inverse cotangent function for a posit number
%   add_binfp         - addition of two fixed point binary numbers
%   add_posit         - addition of two posit numbers
%   add_posit_old     - addition of two posits
%   add_posit_quire   - addition of a posit pa and a quire qb towards a quire
%   add_positm        - addition of two posit matrices
%   asin              - componentwise inverse sine of a posit number or matrix
%   asin_posit        - inverse sine function for a posit number
%   atan              - componentwise inverse tangent of a posit number or matrix
%   atan_posit        - inverse tangent function for a posit number
%   axpyqq            - axpy palp * pa + pb with quires
%   binary            - prints the fields of a posit as binary digits
%   ceil              - ceil for a posit number
%   cos               - componentwise cosine of a posit number or matrix
%   cos_posit         - cos function for a posit number
%   cot               - componentwise cotangent of a posit number or matrix
%   cot_posit         - cotangent function for a posit number
%   ctranspose        - transpose of a (real) posit matrix
%   diag              - diagonal function for a posit matrix or vector
%   disp              - displays a posit as a double
%   display           - displays the double value of a posit
%   div_posit         - division of posits diva / divb
%   div_positm        - componentwise division of two matrices of posit numbers
%   div_positms       - division of a matrix by a scalar, posit numbers
%   dot_posit         - dot product of two posit vectors
%   dot_prod_posit    - dot product of two posit vectors using a quire
%   dot_prod_positq   - dot product of two posit vectors using a quire
%   double            - double precision value of a posit
%   exp               - componentwise exponential of a posit number or matrix
%   exp_posit         - exponential of a posit number
%   fix               - fix for posit numbers
%   floor             - floor for a posit number
%   inv               - inverse of a posit matrix
%   iszero_binfp      - returns true (1) if the floating point binary number is zero
%   iszero_posit      - returns true (1) if the posit number is zero
%   ldivide           - binb .\ bina
%   log               - componentwise natural logarithm of a posit number or matrix
%   log10             - componentwise base 10 logarithm of a posit number or matrix
%   log_posit         - natural logarithm of a posit number
%   lu                - triangular factorization for posit matrices
%   lu_solver_posit   - linear solver for posit linear systems
%   mat_prod_posit    - matrix-matrix product for posits
%   minus             - subtraction of two posit numbers or matrices
%   minus_binfp       - subtraction of two fixed point binary numbers
%   minus_posit       - subtraction of two posits 
%   minus_positm      - subtraction of two posit matrices
%   mldivide          - division of two posit numbers or matrices
%   mpower            - bina ^ p for posit numbers
%   mrdivide          - division of two posit numbers or matrices
%   mtimes            - product of two posit numbers or matrices
%   mul_binfp         - product of two mantissas of posits 
%   mul_posit         - multiplication of two posit numbers
%   mul_positm        - componentwise multiplication of two posit matrices
%   mul_posito        - outer product of two vectors of posit numbers
%   norm              - Frobenius norm of a binary floating point matrix
%   plus              - addition of two posit numbers or matrices
%   posit             - constructor for the class posit, posit arithmetic
%   posit2bin         - converts a posit to a binary string
%   posit2dec         - converts posit to decimal (double floating point)
%   posit2decm        - converts a posit matrix to decimal (double floating point)
%   posit2floatp      - converts a posit to a floatp structure
%   posit2quire       - converts a posit to a quire structure
%   posit2struct      - converts a posit to a structure
%   posit_inv_Newton  - computation of posit 1/d by Newton iteration with normalization
%   power             - bina .^ p for posit numbers
%   printposit        - prints the fields of a posit
%   prod              - prod of vector or matrix of posit numbers
%   rdivide           - componentwise division of two posit numbers or matrices
%   right_shift_binfp - shift bina to the right by k places
%   round2int         - round the posit to the nearest integer
%   sin               - componentwise sine of a posit number or matrix
%   sin_posit         - sine function for a posit number
%   sqrt              - square root of a posit number or matrix
%   sqrt_posit        - square root of a posit number
%   subsasgn          - for posits
%   subsref           - for posits
%   sum               - sum of vector or matrix posit numbers
%   sum_abs_posit     - sum of the absolute values of the components of a posit vector using a quire
%   sum_posit         - sum of the components of a posit vector using a quire
%   tan               - componentwise tangent of a posit number or matrix
%   tan_posit         - tangent function for a posit number
%   times             - componentwise product of two posit numbers or matrices
%   trace             - trace of a posit matrix
%   tril              - lower triangular part of a posit matrix
%   triu              - upper triangular part of a posit matrix
%   uminus            - change signs of bina
%   uplus             - do not change signs of bina
