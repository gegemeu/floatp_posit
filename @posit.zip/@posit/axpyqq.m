function pc = axpyqq(palp,pa,pb);
%AXPYQQ  axpy palp * pa + pb with quires

% in this function, we convert to quires before doing the product

% this is not the posit "standard" in which there is only one quire

% needs the quire class

%
% Author G. Meurant
% May 2020
%

[nalp,malp] = size(palp);

if nalp ~= 1 || malp ~= 1
 error(' axpyq: the first argument must be a scalar')
end % if

[na,ma] = size(pa);
[nb,mb] = size(pb);

if na ~= 1 && ma ~= 1 && nb ~= 1 && mb ~= 1
 error(' axpyq: the two last inputs must be posit vectors')
end % if

nbitsa = pa(1).nbits;
nbitsb = pb(1).nbits;

if nbitsa ~=  nbitsb
 error(' axpyq: the input vectors must have the same value of nbits')
end % if

la = length(pa);
lb = length(pb);
if la ~= lb
 error(' axpyq: the two vectors must have the same length')
end % if

pc = pa;
qalp = quire(palp);

for k = 1:la
 qa = quire(pa(k));
 qb = quire(pb(k));
 qc = add_quire(qb, mul_quire(qalp,qa));
 pc(k) = quire2posit(qc);
end % for k


