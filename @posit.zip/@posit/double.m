function x = double(p);
%DOUBLE double precision value of a posit

%
% Author G. Meurant
% May 2020
%

[n,m]= size(p);

if n == 1 && m == 1
 x = posit2dec(p);
 
else
 x = posit2decm(p);
end % if

