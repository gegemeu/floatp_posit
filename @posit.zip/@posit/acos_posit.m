function binc=acos_posit(bina);
%ACOS_POSIT inverse cosine function for a positt number

% dependancies: posit2dec, add_posit, mul_posit, div_posit

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;

dec = posit2dec(bina);

if abs(dec) > 1
 error(' acos_posit: the argument must have an absolute value less than or equal to 1')
end % if

if abs(dec) < 2^(-nbits)
 binc = posit(pi/2,nbits);
 return
end % if

if abs(dec - 1) < 2^(-nbits)
 binc = posit(0,nbits);
 return
end % if

if abs(dec + 1) < 2^(-nbits)
 binc = posit(pi,nbits);
 return
end % if

one = posit(1,nbits);
two = posit(2,nbits);
pif = posit(pi,nbits);
onehalf = posit(0.5,nbits);

if dec > 0.5
 binc = mul_posit(two, asin_posit(sqrt( mul_posit(onehalf, minus_posit(one, bina)))));
 return
end % if

if dec < -0.5
 binc = minus_posit(pif, mul_posit(two, asin_posit(sqrt( mul_posit(onehalf, add_posit(one, bina))))));
 return
end % if

pis2 = posit(pi/2,nbits);
binc = minus_posit(pis2, asin_posit(bina));





