function binc = prod(bina,dim);
%PROD prod of vector or matrix of posit numbers

% dependancies: mul_posit

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(bina);
nbits = bina.nbits;
if nargin == 1
 dim = 1;
end % if

if na == 1 || ma == 1
 % vector case
 binc = posit(1,nbits);
 for k = 1:max(na,ma)
  binc = mul_posit(binc, bina(k)); 
 end % for k
 return
end % if

if dim == 1
 % prod along the columns
 binc = posit(zeros(1,ma),nbits);
 for j = 1:ma
  s = posit(1,nbits);
  for k = 1:na
   s = mul_posit(s, bina(k,j)); 
  end % for k
  binc(j) = s;
 end % for j
 
else % dim = 2
 % prod along rows
 binc = posit(zeros(na,1),nbits);
 for j = 1:na
  s = posit(1,nbits);
  for k = 1:ma
   s = mul_posit(s, bina(j,k)); 
  end % for k
  binc(j) = s;
 end % for j
 
end % if

