function binc=tan_posit(bina);
%TAN_POSIT tangent function for a posit number

% dependancies: posit2dec, sin_posit, cos_posit

% uses tan = sin / cos, but this is cheating.......

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;

dec = posit2dec(bina);
dec = abs(dec);
dec = mod(dec,2*pi);

if abs(dec - pi/2) < 2^(-nbits)
 fprintf(' tan_posit: caution, the tangent is large, may be Inf \n')
 binc = posit(1e300,nbits); % ???????
 return
end % if

if abs(dec - 3*pi/2) < 2^(-nbits)
 fprintf(' tan_posit: caution, the tangent is large, may be -Inf \n')
 binc = posit(-1e300,nbits); % ???????
 return
end % if

binc = div_posit(sin_posit(bina), cos_posit(bina));

