function bin = posit(x,nbits,struc);
%POSIT constructor for the class posit, posit arithmetic

% x is a double precision scalar or matrix

% bin is a structure with fields: sign, regime, exponent, mantissa, nbits, float

% dependancies: p_set_posit_env, p_dec2posit

%
% Author G. Meurant
% May 2020
%

global round_mode

if isa(x,'posit')
 bin = x;
 return
end % if

if isempty(round_mode)
 round_mode = 1;
end % if

% if ~isfloat(x)
%  error(' posit: the input must be a double or a floatp')
% end % if

env = p_set_posit_env(nbits); % set the standard posit parameters

if nargin == 2
 
bin = p_dec2posit(x,env);
bin = class(bin,'posit');

return

else
 
 if isfield(struc,'I') % a floatp structure
  nbits = struc.nbits;
  env = p_set_posit_env(nbits);
  bin = p_struct2posit(struc,env);
  
 else
  bin = struc; % a posit structure
  
 end % if
 
 bin = class(bin,'posit');
 
end % if





