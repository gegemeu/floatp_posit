function binc=inv(bina);
%INV inverse of a posit matrix

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(bina);

nbits = bina(1,1).nbits;

if na == 1 && ma == 1
 one = posit(1,nbits);
 binc = div_posit(one, bina);
 return
end % if

if na ~= ma
 error(' inv: the matrix must be square')
end % if

binb = posit_eye(nbits,na,na);

binc = bina \ binb;

