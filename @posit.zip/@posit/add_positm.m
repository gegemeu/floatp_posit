function binc=add_positm(bina,binb);
%ADD_POSITM addition of two posit matrices

% Both inputs must have the same parameters (nbits and es). The result will also have
% the same parameters

% dependancies: add_posit

%
% Author G. Meurant
% May 2020
%

[rowa,cola] = size(bina); % number of rows and columns
[rowb,colb] = size(binb);
if rowa ~= rowb || cola ~= colb
 error(' add_positm: incompatible dimensions of inputs')
end % if

% create a posit and set its parameters
binc = bina;

for i = 1:rowa
 for j = 1:cola
  binc(i,j) = add_posit(bina(i,j),binb(i,j));
 end % for j
end % for i

