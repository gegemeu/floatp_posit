function q=posit2quire(pa);
%POSIT2QUIRE converts a posit to a quire structure

%
% Author G. Meurant
% May 2020
%

% compute the total exponent (of 2) for pa
e = [pa.exponent zeros(1,pa.es-length(pa.exponent))]; % pad with zeros
texp = ((-1)^(pa.regime(1,1) + 1)) * (p_regrunlength(pa.regime)) * 2^pa.es + p_bin2dec(e);

nbits = pa.nbits;

env = p_set_posit_env(nbits);
nq = env.nq;
nc = env.nc;

sig = pa.sign;
x = pa.float;
I = [1]; % hidden bit
F = pa.mantissa;
C = zeros(1,nc);

if texp ~= 0
 % we have to shift
 if texp < 0 % shift right
  F = [I F];
  I = [0];
  F = [zeros(1,abs(texp)-1) F];
 else % shift left
  lF = length(F);
  if lF < texp
   F = [F zeros(1,texp+1-lF)];
  end % if
  I = [I F(1:texp)];
  F = F(texp+1:end);
 end % if
end % if texp

lI = length(I);

if lI < nq 
 % pad with zeros
 I = [zeros(1,nq-lI) I];
 
else
 % a part of I goes to C
 C = I(1:lI-nq);
 I = I(lI-nq+1:end);
 lC = length(C);
 if lC > nc
  error(' posit2quire: the number of bits needed for the input is too large for the quire')
 else
  C = [zeros(1,nc-lC) C];
 end % if lC
end % if lI

F = [F zeros(1,nq-length(F))];
  
q = struct('sign',sig,'C',C,'I',I,'F',F,'float',x,'nq',nq,'nc',nc,'nbits',nbits);

% q = quire(x,nbits,q);









