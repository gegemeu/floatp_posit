function binc=ldivide(bina,binb);
%LDIVIDE binb .\ bina

%
% Author G. Meurant
% May 2020
%

if ~isa(bina,'posit')
 bina = posit(bina,binb(1).nbits);
end % if 

if ~isa(binb,'posit')
 binb = posit(binb,bina(1).nbits);
end % if 

[na,ma] = size(bina);
[nb,mb] = size(binb);

if na ~= nb || ma ~= mb
 error(' ldivide: the inputs must have the same size')
end % if

binc = bina;

for i = 1:na
 for j = 1:mb
  binc(i,j) = div_posit(binb(i,j), bina(i,j));
 end % for j
end % for j

