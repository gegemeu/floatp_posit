function pc = add_posit_old(pa,pb);
%ADD_POSIT_OLD addition of two posits

% the new code is faster

% Both inputs must have the same parameters (nbits and es). The result will also have
% the same parameters

% This is mainly taken from the Octave code of diegofgcoelho@gmail.com

%
% Translated to Matlab by G. Meurant
% March 2020
%

% check if one of the arguments is zero. If yes, return the other 
if iszero_posit(pa)
 pc = pb;
 return
end % if

if iszero_posit(pb)
 pc = pa;
 return
end % if

paa = pa;
pbb = pb;

% create a posit element and set its parameters
pc = pa;

pc.float = posit2dec(pa) + posit2dec(pb); % double precision value

% fix mantissa sizes
dsizea = length(pa.mantissa) - length(pb.mantissa);

% fix the exponents
if length(pa.exponent) <= pa.es
 pa.exponent = [zeros(1,pa.es - length(pa.exponent)) pa.exponent];
end % if
if length(pb.exponent) <= pb.es
 pb.exponent = [zeros(1,pb.es - length(pb.exponent)) pb.exponent];
end % if

% fix the mantissas
% Note that it includes the hidden bit as well. The 1 in front of the actual mantissa represents
% the hidden bit. The two zeros represents, respectively, the sign (the first one) in
% 2's complement and the second one is a bit in case of overflow
pa.mantissa = [0 0 1 pa.mantissa];
pb.mantissa = [0 0 1 pb.mantissa];
pa.mantissa = [pa.mantissa zeros(1, max(-dsizea, 0))];
pb.mantissa = [pb.mantissa zeros(1, max(dsizea, 0))];

% find the largest posit
% The (length(pa.regime)-1) is necessary to remove from the counting the
% last regime bit. The ((-1)^(regime(1,1)+1)) is necessary to account for the
% regime bit sequence for the regime bits regarding the sign. The regime bits
% have size greater than 1, always, so if the last bit is 1, it means that
% the sequence is compounded by 0's followed by 1, which implies a negative
% coefficient due to the regime bits. If the last bit is 0, it means that the
% sequence is of 1's followed by 0, which in this case implies that the
% coefficient due to the regime bits is positive

taregime = ((-1)^(pa.regime(1,1) + 1)) * p_regrunlength(pa.regime);
tbregime = ((-1)^(pb.regime(1,1) + 1)) * p_regrunlength(pb.regime);

taexp = p_bin2dec(pa.exponent);
tbexp = p_bin2dec(pb.exponent);

% total exponent
tatotalexp = taregime * 2^pa.es + taexp;
tbtotalexp = tbregime * 2^pb.es + tbexp;

% exponent alignment
amantsize = length(pa.mantissa);
bmantsize = length(pb.mantissa);

if tatotalexp > tbtotalexp
 ddiff = tatotalexp - tbtotalexp;
 if ddiff > bmantsize
  % there is nothing to do but return pa
  pc = paa;
  return
  
 else
  % we need to align the exponents
  pb.mantissa = [zeros(1,ddiff) pb.mantissa(1,1:bmantsize)];
  pa.mantissa = [pa.mantissa(1,1:amantsize) zeros(1,ddiff)];
  pb.exponent = pa.exponent;
  pb.regime = pa.regime;
  
  pc.regime = pa.regime;
  pc.exponent = pa.exponent;
 end % if ddiff
 
else
 ddiff = tbtotalexp - tatotalexp;
 if ddiff > amantsize
  % there is nothing to do but return pb
  pc = pbb;
  return
  
 else
  % if the else statement occurs, we need to align the exponents
  pa.mantissa = [zeros(1,ddiff) pa.mantissa(1,1:amantsize)];
  pb.mantissa = [pb.mantissa(1,1:bmantsize) zeros(1,ddiff)];
  pa.exponent = pb.exponent;
  pa.regime = pb.regime;
  
  pc.regime = pb.regime;
  pc.exponent = pb.exponent;
 end % if ddiff
 
end % if tatotalexp

tcregime = ((-1)^(pc.regime(1,1)+1)) * p_regrunlength(pc.regime);

% End of aligning the exponents
% from now on, the mantissas have been shifted accordingly and we can proceed
%  with additon/subtraction according the input signs

% temporary variables with the mantissas with appropriate 2's complement representation
tamant = pa.mantissa;
tbmant = pb.mantissa;
if pa.sign == 1
 tamant = p_addbits(not(tamant), zeros(1,length(tamant)), 1);
end % if
if pb.sign == 1
 tbmant = p_addbits(not(tbmant), zeros(1,length(tbmant)), 1);
end % if
% end of section assigning mantissa values and sign

rmant = p_addbits(tamant,tbmant);

% check resulting sign and possible overflow
pc.sign = rmant(1,1);
if pc.sign == 1
 % if the result is negative, take the 2's complement
 rmant = p_addbits(not(rmant), zeros(size(rmant)), 1);
end % if
% remove the sign bit
rmant = rmant(1,2:end);
% search for the first 1 after the sign
yy = find(rmant);
if ~isempty(yy)
 expshift = -(yy(1) - 2);
 
else
 % if yy is empty, it means that the mantissa is totally zero
 pc.sign = 0;
 pc.regime = zeros(1,pc.nbits - pc.es -1 - 1);
 pc.mantissa = 0;
 return
end % if

texp = [0 pc.exponent];

while expshift ~= 0
 if expshift < 0
  expshift = expshift + 1;
  stexp = texp(1);
  texp = p_addbits(texp, ones(size(texp)));
  if (xor(stexp, texp(1)))
   tcregime = tcregime - 1;
  end % if
  
  % shift the mantissa
  rmant = [rmant(1,2:end) 0];
  
 else
  expshift = expshift - 1;
  stexp = texp(1);
  texp = p_addbits(texp, zeros(1,length(texp)), 1);
  if xor(stexp, texp(1))
   tcregime = tcregime + 1;
  end % if
  
  % shift the mantissa
  rmant = [0 rmant(1,1:end-1)];
 end %if
 
end % while

pc.exponent = texp(1,2:end);

% determine the new regime bits for pc
if tcregime >= 0
 pc.regime = [ones(1,tcregime+1) 0];
 
else
 pc.regime = [zeros(1,-tcregime) 1];
end % if

% at this point, exponent, regime its and mantissa for pc are all with correct values,
% expect that we need to round the mantissa and adjust its size to fit pc

% rounding
rmant = rmant(1,2:end);
len = max(pc.nbits - (length(pc.regime) + pc.es+1) + 1,1);
% [rmant,rmcarry] = p_roundmanta(rmant, len);
[rmant,rmcarry] = fix_round_bin(rmant,len,pc.sign);

% adjust the exponent and regime bits in case of overflow
if rmcarry == 1
 [pc.exponent,expcarry] = p_addbits(pc.exponent, zeros(1,pc.es), 1);
 
 if expcarry == 1
  % update the new bits for pc
  tcregime = tcregime + 1;
  
  if tcregime >= 0
   pc.regime = [ones(1,tcregime+1) 0];
   
  else
   pc.regime = [zeros(1,-tcregime) 1];
  end % if
  
 end % if expcarry
 
 pc.mantissa = rmant(1,1:max((pc.nbits-(length(pc.regime)+pc.es+1)), 1));
 
else
 % if there is no carry, there is nothing to do but just return pc
 pc.mantissa = rmant(1,2:max((pc.nbits-(length(pc.regime)+pc.es+1)+1), 1)); % eliminating the leading bit
 
end % if rmcarry

% clean the exponent
pc.exponent = pc.exponent(1,1:min(pc.es, pc.nbits-1-length(pc.regime)));



