function binc=exp_posit(bina);
%EXP_POSIT exponential of a posit number

% dependancies: posit2dec, round2int, add_posit, mul_posit

%
% Author G. Meurant
% May 2020
%

y = abs(bina);
decp = posit2dec(bina);
decy = abs(decp);
nbits = bina.nbits;

if decy < 2^(-nbits)
 binc = posit(1,nbits);
 return
end % if

if decp > 700
 error(' exp_posit: bina is too large') 
end % if

if decp < 0 && decy > 750
 binc = posit(0,nbits);
 return
end % if

% ln2 = 0.69314718055994528622676398299518; % log(2)

% ln21 = 1.4426950408889634073599246810018921374; % 1 / log(2)
ln21 = posit(1.4426950408889634073599246810018921374,nbits);

% c1 = 0.693359375000000000; % 355 / 512
c1 = posit(0.693359375000000000,nbits);
% c2 = -2.121944400546905827679e-4;
c2 = posit(-2.121944400546905827679e-4,nbits); % c1 + c2 = log(2)

n = round2int( mul_posit(bina, ln21)); % round to nearest integer
decn = posit2dec(n);

g = minus_posit( (minus_posit(bina, mul_posit(n,c1))), mul_posit(n,c2)); % (p - n * c1) - n * c2;

p1 = posit(1.66666666666666019037e-01,nbits);
p2 = posit(-2.77777777770155933842e-03,nbits);
p3 = posit(6.61375632143793436117e-05,nbits);
p4 = posit(-1.65339022054652515390e-06,nbits);
p5 = posit(4.13813679705723846039e-08,nbits); 

t = mul_posit(g,g); 

% c  = g - t * (p1 + t * (p2 + t * ( p3 + t * (p4 + t * p5) ) ) );
c  = minus_posit(g, mul_posit(t, add_posit(p1, mul_posit(t, add_posit(p2, mul_posit(t, add_posit(p3, mul_posit(t, add_posit(p4, mul_posit(t,p5) ) ) ) ) ) ) ) ) );

one = posit(1,nbits);
two = posit(2,nbits);
y = minus_posit(one, minus_posit( div_posit( mul_posit(g,c), minus_posit(c,two) ), g));  % 1 - ( [(g * c) / (c - 2)] - g); 

if decn == 0
 binc = y;
else
 n2 = posit(2^decn,nbits);
 binc = mul_posit(y,n2); % ex = y * 2^n
end % if
 
 
 
 
 


