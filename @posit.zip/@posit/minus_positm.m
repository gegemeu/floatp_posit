function binc=minus_positm(bina,binb);
%MINUS_POSITM subtraction of two posit matrices

% Both inputs must have the same parameters (nbits and es). The result will also have
% the same parameters

% dependancies: minus_posit

%
% Author G. Meurant
% May 2020
%

[rowa,cola] = size(bina); % number of rows and columns
[rowb,colb] = size(binb);
if rowa ~= rowb || cola ~= colb
 error(' minus_positm: incompatible dimensions of inputs')
end % if

% Create a posit and set its parameters
binc = bina;

for i = 1:rowa
 for j = 1:cola
  binc(i,j) = minus_posit(bina(i,j),binb(i,j));
 end % for j
end % for i

