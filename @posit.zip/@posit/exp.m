function binc = exp(bina);
%EXP componentwise exponential of a posit number or matrix

% dependancies: exp_posit

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(bina);

if na == 1 && ma == 1
 binc = exp_posit(bina);
 
else
 binc = bina;
 [na,ma] = size(bina);
 for i = 1:na
  for j = 1:ma
   binc(i,j) = exp_posit(bina(i,j));
  end % for j
 end % for j
 
end % if



