function binc = plus(bina,binb);
%PLUS addition of two posit numbers or matrices

% dependancies: add_posit, add_positm

%
% Author G. Meurant
% May 2020
%

if ~isa(bina,'posit')
 bina = posit(bina,binb(1).nbits);
end % if 

if ~isa(binb,'posit')
 binb = floatp(binb,bina(1).nbits);
end % if 

[na,ma] = size(bina);
[nb,mb] = size(binb);

if na == 1 && ma == 1 && nb == 1 && mb == 1 % scalar case
 binc = add_posit(bina,binb);
 return
end % if

if na == 1 && ma == 1 && (nb ~= 1 || mb ~= 1) % scalar + matrix
 binc = binb;
 for i = 1:nb
  for j = 1:mb
   binc(i,j) = add_posit(bina, binb(i,j));
  end % for j
 end % for i
 return
end % if

if nb == 1 && mb == 1 && (na ~= 1 || ma ~= 1) % matrix + scalar
 binc = bina;
 for i = 1:na
  for j = 1:ma
   binc(i,j) = add_posit(binb, bina(i,j));
  end % for j
 end % for i
 return
end % if

% matrix + matrix

binc = add_positm(bina,binb);




