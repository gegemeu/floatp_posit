function bin = posit2bin(p);
%POSIT2BIN converts a posit to a binary string

%
% Author G. Meurant
% May 2020
%

bin = [p.sign p.regime p.exponent p.mantissa];

if length(bin) > p.nbits
 
 if p.exponent == 0
  bin = [p.sign p.regime p.mantissa];
 end % if
 
end % if