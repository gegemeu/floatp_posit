function s=norm(bina);
%NORM Frobenius norm of a binary floating point matrix

% we are just able to compute the Frobenius norm (no SVD)
% however, we could have use the floating point value

%
% Author G. Meurant
% May 2020
%

binb = bina .* bina;

su = sum(sum(binb));

s = sqrt(su);

