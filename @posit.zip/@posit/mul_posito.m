function binc = mul_posito(bina,binb);
%MUL_POSITO outer product of two vectors of posit numbers

% Both inputs must have the same parameters (nbits and es). The result will also have
% the same parameters

% dependancies: mul_posit

%
% Author G. Meurant
% May 2020
%

nbits = min(bina(1).nbits,binb(1).nbits);

[rowa,cola] = size(bina); % number of rows and columns
[rowb,colb] = size(binb);

if cola ~= 1
 bina = bina';
end % if

if rowb ~= 1
 binb = binb';
end % if

% create a binary element and set its parameters
binc = posit(zeros(rowa,colb),nbits);

for i = 1:rowa
 for j = 1:colb
  binc(i,j) = mul_posit(bina(i),binb(j));
 end % for j
end % for i