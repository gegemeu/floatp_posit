function X = subsasgn(X,S,Y)
%SUBSASGN for posits

if isa(Y,'posit')
 Y = posit2decm(Y);
end % if

Xd = posit2decm(X);
Xd = subsasgn(Xd,S,Y);
nbits = X(1).nbits;
X = posit(Xd,nbits);

