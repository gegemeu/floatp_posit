function binc = minus_posit(bina,binb);
%MINUS_POSIT subtraction of two posits 

% bina - binb

% both inputs must have the same parameters (nbits and es). The result will also have
% the same parameters

% Dependancies: iszero_posit, add_posit

%
% Author G. Meurant
% May 2020
%

% 0 - 0, changing the sign in this case would be a bug
if iszero_posit(bina) && iszero_posit(binb)
 binc = bina;
 return
end % if

% check if one of the arguments is zero. If yes, return the other 
if iszero_posit(bina) 
 binc = -binb;
 return
end % if

if  iszero_posit(binb)
 binc = bina;
 return
end % if

binb.sign = not(binb.sign);

binc = add_posit(bina,binb);


