function b=binary(bin);
%BINARY prints the fields of a posit as binary digits

%
% Author G. Meurant
% May 2020
%

[n,m] = size(bin);

b = cell(n,m);

for i = 1:n
 for j = 1:m
  p = bin(i,j);
  sig = p.sign;
  reg = p.regime;
  expo = p.exponent;
  mant = p.mantissa;
  b(i,j) = {[ num2str(sig) ' ' p_bin2str(reg) ' ' p_bin2str(expo) ' ' p_bin2str(mant) ]};
 end % for j
end % for i

