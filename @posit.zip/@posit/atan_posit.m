function binc=atan_posit(bina);
%ATAN_POSIT inverse tangent function for a posit number

% dependancies: add_posit, mul_posit, div_posit, sqrt_posit, asin_posit

% uses the relation between atan and asin, but this is cheating.......

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;
one = posit(1,nbits);

den = sqrt_posit( add_posit(one, mul_posit(bina, bina)));

binc = asin_posit( div_posit(bina, den));

