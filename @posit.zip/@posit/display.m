function display(x);
%DISPLAY displays the double value of a posit

%
% Author G. Meurant
% May 2020
%

    disp(' ');
    disp([inputname(1),' = '])
    disp(' ');
    disp(double(x))
    disp(' ');
