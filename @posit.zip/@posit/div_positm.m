function binc = div_positm(bina,binb);
%DIV_POSITM componentwise division of two matrices of posit numbers

% dependancies: div_posit

%
% Author G. Meurant
% April 2020
%

[rowa,cola] = size(bina); % number of rows and columns
[rowb,colb] = size(binb);
if rowa ~= rowb || cola ~= colb
 error(' div_posit: incompatible dimensions of inputs')
end % if

% create a binary element and set its parameters
binc = bina;

for i = 1:rowa
 for j = 1:cola
  binc(i,j) = div_posit(bina(i,j),binb(i,j));
 end % for j
end % for i