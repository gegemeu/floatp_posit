function binc=cos_posit(bina);
%COS_POSIT cos function for a posit number

% dependancies: sin_bfl, minus_posit, mul_posit, sqrt_posit

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;

s = sin_posit(bina); % sine

% c = sqrt(1 - s^2);  this is to maintain s^2 + c^2 = 1 to working precision
% if s is close to 1, 1 - s^2 can be negative

one = posit(1,nbits);
os = minus_posit( one, mul_posit(s,s));

if os.float == 0
 binc = posit(0,nbits);
 return
 
elseif os.float < 0
 os.sign = 0;
 os.float = abs(os.float);
end % if

binc = sqrt_posit(os); % this is > 0

y = abs(bina);
z = rem(posit2dec(y),2*pi);

if z > pi/2 && z < 3*pi/2
 binc.sign = ~binc.sign;
 binc.float = -binc.float;
end % if

