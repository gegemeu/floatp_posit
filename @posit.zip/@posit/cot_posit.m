function binc=cot_posit(bina);
%COT_POSIT cotangent function for a posit number

% dependancies: tan_posit

% uses cot = cos / sin, but this is cheating.......

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;
one = posit(1,nbits);

binc = div_posit(one, tan_posit(bina));

