function binc=minus_binfp(bina,binb);
%MINUS_BINFP subtraction of two fixed point binary numbers

% bina - binb

% bin is a structure containing binary numbers
% representing the sign, the integer part and the fractional part as well
% as the double precision value if available

% in this function bina and binb must have the same nbits and we do not
% remove the trailing zero bits

% dependancies: add_binfp, p_minus_bin, p_isge_bin

%
% Author G. Meurant
% May 2020
%

if bina.nbits ~= binb.nbits
 error(' minus_binfp: the two inputs must have the same value of nbits')
end % if

nbits = bina.nbits;

siga = bina.sign;
sigb = binb.sign;

if iszero_binfp(bina) == 1
 binc = binb;
 binc.sign = ~binb.sign;
 binc.float = -binb.float;
 return
end % if

if iszero_binfp(binb) == 1
 binc = bina;
 return
end % if

% we have to look at the signs and the absolute values

if siga == 0 && sigb == 1 % binc = bina + | binb |
 binb.sign = 0;
 binb.float = -binb.float;
 binc = add_binfp(bina,binb);
 return
end % if

if siga == 1 && sigb == 0 % binc = -( | bina | + binb)
 bina.sign = 0;
 bina.float = -bina.float;
 binc = add_binfp(bina,binb);
 binc.sign = 1;
 binc.float = -binc.float;
 return
end % if

if siga == 0 && sigb == 0
 ba = [bina.I bina.F];
 bb = [bina.I binb.F];
 
 if p_isge_bin(ba,bb) % a > b
  [bin,~] = p_minus_bin(ba,bb,0);
  % F = last nbits bits of s
  ls = length(bin);
  I = bin(1:ls-nbits);
  F = bin(ls-nbits+1:end);
  sig = 0;
  ind = find(I);
  if isempty(ind)
   I = [];
  else
   I = I(ind(1):end);
  end % if
  x = p_bin2dec(I) + p_bin2frac(F); % double floating point value
 
  binc = struct('sign',sig,'I',I,'F',F,'float',x,'nbits',nbitsa);
  return
  
 else % a < b
  binc = minus_binfp(binb,bina);
  binc.sign = ~binc.sign;
  binc.float = - binc.float;
  return
  
 end % if p_isge
end % if

if siga == 1 && sigb == 1
 bina.sign = 0;
 bina.float = -bina.float;
 binb.sign = 0;
 binb.float = -binb.float;
 ba = [bina.I bina.F];
 bb = [binb.I binb.F];
 
 if p_isge_bin(ba,bb) % | a | >= | b |, binc = -(| a | - | b |)
  binc = minus_binfp(bina,binb);
  binc.sign = ~binc.sign;
  binc.float = -binc.float;
  return
  
 else % | a | < | b |, binc = | b | - | a |
  binc = minus_binfp(binb,bina);
  return
  
 end % if isge
 
end % if siga



