function binc = uplus(bina);
%UPLUS do not change signs of bina

%
% Author G. Meurant
% May 2020
%

binc = bina;



