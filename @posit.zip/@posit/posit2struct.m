function bin=posit2struct(p);
%POSIT2STRUCT converts a posit to a structure

% the structure can be used with the functions of p_posit

%
% Author G. Meurant
% May 2020
%

bin = struct('sign',[],'regime',[],'exponent',[],'mantissa',[],'nbits',[],'es',[],'float',0);

sig = p.sign;
reg = p.regime;
expo=p.exponent;
mantiss = p.mantissa;
nbits = p.nbits;
es = p.es;
x = p.float;

bin.sign = sig;
bin.regime = reg;
bin.exponent = expo;
bin.mantissa = mantiss;
bin.nbits = nbits;
bin.es = es;
bin.float = x;

