function binc=acot_posit(bina);
%ACOT_POSIT inverse cotangent function for a posit number

% dependancies: posit2dec, sin_posit, cos_posit

% uses the relation between acot and asin, but this is cheating.......

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;
one = posit(1,nbits);

den = sqrt_posit( add_posit(one, mul_posit(bina, bina)));

binc = asin_posit( div_posit(one, den));

