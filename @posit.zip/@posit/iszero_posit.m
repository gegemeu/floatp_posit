function x=iszero_posit(p);
%ISZERO_POSIT returns true (1) if the posit number is zero

%
% Author G. Meurant
% May 2020
%

x = 0;

sig = p.sign;
reg = p.regime;
expo = p.exponent;
mant = p.mantissa;


if sum(sig) == 0 && sum(reg) == 0 && sum(expo) == 0 && sum(mant) == 0
 x = 1;
end % if


