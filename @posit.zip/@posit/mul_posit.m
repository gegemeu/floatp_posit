function binc=mul_posit(bina,binb);
%MUL_POSIT multiplication of two posit numbers

% we convert the posits to 1.xxxxx 2^e before doing the binary multiplication

% Dependancies: mul_binfp, p_round_bin, iszero_posit

%
% Author G. Meurant
% May 2020
%

nbitsa = bina.nbits;
nbitsb = binb.nbits;

if nbitsa ~= nbitsb
 error(' mul_posit: the inputs must have the same value of nbits')
end % if

if iszero_posit(bina)
 % bina is zero
 binc = bina;
 return
end % if

if iszero_posit(binb) 
 % binb is zero
 binc = binb;
 return
end % if

% compute the total exponents (of 2) for bina and binb
ea = [bina.exponent zeros(1,bina.es-length(bina.exponent))]; % pad with zeros
tea = ((-1)^(bina.regime(1,1) + 1)) * (p_regrunlength(bina.regime)) * 2^bina.es + p_bin2dec(ea);

eb = [binb.exponent zeros(1,binb.es-length(binb.exponent))]; % pad with zeros
teb = ((-1)^(binb.regime(1,1) + 1)) * (p_regrunlength(binb.regime)) * 2^binb.es + p_bin2dec(eb);

e = tea + teb; % exponent

bin = mul_binfp(bina,binb); % multiplication of the significands
% bin is a structure

% we may have to shift to normalize the result

lenI = length(bin.I);
I = bin.I;
F = bin.F;
sig = bin.sign;

if lenI ~= 1
 
 if lenI ~= 0
  % we have to shift right
  F = [I(2:end) F]; % shift
  [F,cnext] = p_round_bin(F,nbitsa,sig); % double rounding???????????????????
  if cnext == 1 % we have to shift right again, I = [1 0]
   F = [0 F];
   F = F(1:nbitsa); % we chop this time
  end % if cnext
  I = [1];
  e = e + lenI - 1; % adjust the exponent
  
 else
  % we have to shift left
  ind = find(F);
  I = [1];
  F = F(ind(1)+1:end);
  lenF = length(F);
  F = [F zeros(1,nbitsa-lenF)]; % pad with zeros
  e = e - ind(1);
  
 end % if lenI ~= 0
 
end % if

x = (1 + p_bin2frac(F)) * 2^e; % floating point value

if sig == 1
 x = -x;
end % if

binc = struct('sign',sig,'I',I,'F',F,'E',e,'float',x,'nbits',nbitsa);

% convert this to a posit

binc = posit(x,nbitsa,binc);








