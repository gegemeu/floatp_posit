function binc = div_positms(bina,binb);
%DIV_POSITMS division of a matrix by a scalar, posit numbers

% bina / binb, binb is a scalar

% dependancies: div_posit

%
% Author G. Meurant
% May 2020
%

[rowa,cola] = size(bina); % number of rows and columns
[rowb,colb] = size(binb);
if rowb ~= 1 || colb ~= 1
 error(' div_positms: binb must be a scalar')
end % if

% Create a posit and set its parameters
binc = bina;

for i = 1:rowa
 for j = 1:cola
  binc(i,j) = div_posit(bina(i,j),binb);
 end % for j
end % for i

