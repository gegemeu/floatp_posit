function qc = plus(qa,qb);
%PLUS addition of two quires

% dependancies: add_quire

%
% Author G. Meurant
% May 2020
%
 
qc = add_quire(qa,qb);

