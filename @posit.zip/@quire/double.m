function x = double(q);
%DOUBLE double precision value of a quire

%
% Author G. Meurant
% May 2020
%

x = quire2dec(q);
 


