function qc=mul_quire(qa,qb);
%MUL_QUIRE product of two quires, qc = qa * qb

% note that this is not in the posit "standard"
% but this can be useful for the dot product if we first convert the posits to quires

%
% Author G. Meurant
% May 2020
%

nqa = qa.nq;
nqb = qb.nq;
nca = qa.nc;
ncb = qb.nc;

if (nqa ~= nqb) || (nca ~= ncb)
 error(' mul_quire: the two quires must have the same parameters')
 % we can eventually convert the smallest one to the size of the largest one????
end % if

nq = nqa;
nc = nca;
nqc = nqa + nca;
nmax = nqc + nqa;

% sign
sig = xor(qa.sign,qb.sign);

% concatenation of C, I and F 
sa = [qa.C, qa.I, qa.F];
ea = [nqc-1:-1:-nq]; % powers of 2
emin = ea(end);
sb = [qb.C, qb.I, qb.F];
lsa = length(sa);
lsb = length(sb);

if lsa ~= lsb
 error(' mul_quire: lsa is different from lsb')
end % if

s = zeros(1,lsa); % to accumulate the products

inda = find(sa == 1);
indb = find(sb == 1);

for i = indb
 % multiply sa by sb(i)
 temp = zeros(1,lsa);
 
 for j = inda
  eaij = ea(i) + ea(j); % power of 2
  
%   if eaij > ea(1)
%    fprintf(' mul_quire: an index is too large, eaij = %d, max = ea(1) = %d \n',eaij,ea(1)) % this must not happen
%   end % if
  
%   if eaij < ea(end)
%    fprintf(' an index is too small, eaij = %d, min = ea(end) = %d \n',eaij,ea(end)) % this must not happen
%   end % if
  
  % find the index where to store it in temp
%   index = i + j - nq;
%   index = find(ea == eaij); % can this be done more efficiently?
  index = nmax - (eaij - emin);
  
  if index > nmax
   break
  end % if
  
  if index < 1
   fprintf('\n i = %d, j = %d, nq = %d, i+j-nq = % d \n',i,j,nq,index)
   error(' mul_quire: wrong index i+j-nq')
  end % if
  
  temp(index) = 1;
 end % for j
 
%  if length(temp) > lsa
%   fprintf(' Caution: the length of temp has increased \n')
%  end % if
 
 ls = length(s);
 [s,~] = p_addbin(s,temp); % pb: carry ??????
 
%  if length(s) > ls
%   fprintf(' the length of s is increasing, before = % d, after % d \n',ls,length(s))
%  end % if
 
end % for i

ls = length(s);
if ls > (2 * nq + nc)
 error(' mul_quire: the result is longer than 2 nq + nc with length %d \n',ls)
end % if

% F = last nq bits
F = s(ls-nq+1:end);

I = s(ls-2*nq+1:ls-nq);

C = s(1:ls-2*nq);
if length(C) < nc
 C = [zeros(1,nc-length(C)) C];
end % if

qc = qa;
qc.sign = sig;
qc.C = C;
qc.I = I;
qc.F = F;
qc.float = quire2dec(qc);




