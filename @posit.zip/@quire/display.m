function display(x);
%DISPLAY displays the quire as a double

%
% Author G. Meurant
% May 2020
%

disp(' ');
disp([inputname(1),' = '])
disp(' ');
disp(double(x))
disp(' ');
