% @QUIRE
%
% Files
%   add_quire      - addition of two quires qa + qb
%   disp           - displays a quire as a double
%   display        - displays the quire as a double
%   double         - double precision value of a quire
%   minus          - subtraction of two quires
%   minus_quire    - subtraction of two quires, bina - binb
%   mul_quire      - product of two quires, qc = qa * qb
%   plus           - addition of two quires
%   quire          - constructor for the class quire, posit arithmetic
%   quire2dec      - converts a quire to decimal
%   quire2posit    - converts a quire to a posit with same nbits
%   set_quire2zero - returns a zero quire q = 0
%   uminus         - change signs of bina
%   uplus          - do not change signs of bina
