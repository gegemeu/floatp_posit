function disp(x)
% DISP displays a quire as a double

%
% Author G. Meurant
% May 2020
%

%
% Author G. Meurant
% May 2020
%

disp(double(x))

