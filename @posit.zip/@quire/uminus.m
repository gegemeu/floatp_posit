function binc = uminus(bina);
%UMINUS change signs of bina

%
% Author G. Meurant
% May 2020
%

binc = bina;

binc.sign = ~bina.sign;

