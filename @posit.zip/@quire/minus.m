function qc = minus(qa,qb);
%MINUS subtraction of two quires

% dependancies: minus_quire

%
% Author G. Meurant
% May 2020
%
 
qc = minus_quire(qa,qb);

