function dec=quire2dec(q);
%QUIRE2DEC converts a quire to decimal

% dependancies: p_bin2dec, p_bin2frac

%
% Author G. Meurant
% May 2020
%

I = q.I;
C = q.C;
F = q.F;
sig = q.sign;

I = [C I];
ind = find(I);
if ~isempty(ind)
 I(ind(1):end);
 integ = p_bin2dec(I(ind(1):end));
else
 integ = 0;
end % if

FF = fliplr(F);
ind = find(FF);
if ~isempty(ind)
 F = fliplr(FF(ind(1):end));
 frac = p_bin2frac(F);
else
 frac = 0;
end % if

dec = integ + frac;

if sig == 1
 dec = -dec;
end % if

