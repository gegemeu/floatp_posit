function p = quire2posit(q);
%QUIRE2POSIT converts a quire to a posit with same nbits

% this is not always possible if the quire cannot be represented by the posit? We must check that

% dependancies: p_set_posit_env, p_find_regime_expo, p_dec2bin, p_round_bin, p_bin2frac

%
% Author G. Meurant
% May 2020
%

nbits = q.nbits;
env = p_set_posit_env(nbits);
es = env.es;

sig = q.sign;
C = q.C;
I = q.I;
F = q.F;

if sum(C)+sum(I)+sum(F) == 0
 % q is zero
 p = posit(0,nbits);
 return
end % if

% shift the C, I part to obtain 1.xxx... 2^e and compute the exponent e

I = [C I];
ind = find(I);

if ~isempty(ind)
 % we have to shift right
 ind1 = ind(1);
 F = [I(ind1+1:end) F];
 e = length(I(ind1+1:end));
 I = [1];
 
else % I is zero, we have to shift F to the left
 ind = find(F); % F cannot be zero
 ind1 = ind(1);
 I = [1];
 F = F(ind1+1:end);
 e = -ind1;
 
end % if

[k,m,us] = p_find_regime_expo(e,es);

expo = p_dec2bin(m,es);

if k > 0
 reg = [ones(1,k+1) 0];
 
elseif k == 0
 reg = [1 0];
 
else
 reg = [zeros(1,-k) 1];
end % if

lreg = length(reg);
% number of bits left for the mantissa
nmant = nbits - es - 1 - lreg;

if nmant > 0
 [mantiss,cnext] = p_round_bin(F,nmant,sig);
 
 if cnext == 1
  % there is a carry from the rounding, we have to shift right and adjust the exponents
  mantiss = [0 mantiss(1:nmant-1)];
  pp = 2^es;
  kmp = k * pp + m + 1;
  [kk,mm] = p_find_regime_expo(kmp,es); % we must recompute the exponents
  if kk > 0
   reg = [ones(1,kk+1) 0];
   
  elseif kk == 0
   reg = [1 0];
   
  else
   reg = [zeros(1,-kk) 1];
  end % if
  
  expo = p_dec2bin(mm,es);
  
 end % if cnext
 
else
 mantiss = [];
end % if

struc = struct('sign',sig,'regime',reg,'exponent',expo,'mantissa',mantiss,'nbits',nbits,'es',es,'float',0);

x = (1 + p_bin2frac(F)) * 2^e;
struc.float = x;

p = posit(x,nbits,struc);





