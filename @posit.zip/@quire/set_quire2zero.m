function q=set_quire2zero(q);
%SET_QUIRE2ZERO returns a zero quire q = 0

%
% Author G. Meurant
% May 2020
%

% q = struct('sign',sig,'I',zeros(1,nq),'F',zeros(1,nq),'C',zeros(1,nc),'float',p_posit2dec(p),'nq',nq,'nc',nc);

nq = q.nq;
nc = q.nc;

q.sign = 0;
q.I = zeros(1,nq);
q.F = zeros(1,nq);
q.C = zeros(1,nc);
q.float = 0;



