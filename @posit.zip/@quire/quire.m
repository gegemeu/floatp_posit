function q = quire(x,nbits,struc);
%QUIRE constructor for the class quire, posit arithmetic

% x is a double precision scalar or a posit or a quire 

% dependancies: q_dec2quire, posit2quire

%
% Author G. Meurant
% May 2020
%

global round_mode

if isa(x,'quire')
 q = x;
 return
end % if

if isa(x,'posit')
 q = posit2quire(x);
 q = class(q,'quire');
 return
end % if

if isa(x,'floatp') % a floatp structure
 q = floatp2quire(x);
 q = class(q,'quire');
 return
end % if

if isempty(round_mode)
 round_mode = 1;
end % if

if nargin == 2
 
 q = q_dec2quire(x,nbits);
 q = class(q,'quire');
 return
 
else
 
 q = struc; % a quire structure
 
end % if

q = class(q,'quire');







