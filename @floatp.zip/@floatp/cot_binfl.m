function binc=cot_binfl(bina);
%COT_BINFL cotangent function for a binary floating point number

% dependencies: floatp, tan_binfl, div_binfl

% uses cot = cos / sin, but this is cheating.......

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;
one = floatp(1,nbits);

binc = div_binfl(one, tan_binfl(bina));

