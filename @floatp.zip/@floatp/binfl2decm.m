function decm = binfl2decm(binm);
%BINFL2DECM binary floating point to double matrix

% nbits bits in the fractional part

% dependencies: binl2dec

%
% Author G. Meurant
% May 2020
%

[row,col] = size(binm);
decm = zeros(row,col);

for i = 1:row
 for j = 1:col
  decm(i,j) = binfl2dec(binm(i,j));
 end % for j
end % for i



