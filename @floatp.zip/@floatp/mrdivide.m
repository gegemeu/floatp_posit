function binc = mrdivide(bina,binb);
%MRDIVIDE  division of two binary floating point numbers or matrices
% bina / binb

% for matrices, binc * binb = bina, binc is a row vector

% dependencies: floatp, ctranspose, mldivide, div_binfl

%
% Author G. Meurant
% May 2020
%

if ~isa(bina,'floatp')
 bina = floatp(bina,binb(1).nbits);
end % if 

if ~isa(binb,'floatp')
 binb = floatp(binb,bina(1).nbits);
end % if 

[na,ma] = size(bina);
[nb,mb] = size(binb);

if na == 1 && ma == 1 && nb == 1 && mb == 1
 binc = div_binfl(bina,binb);
 
else
 if nb ~= mb
  error(' mrdivide: binb must be a square matrix')
 end % if
 if ma ~= mb
  error(' mrdivide: incompatible dimensions')
 end % if
 
 binbt = ctranspose(binb);
 binta = ctranspose(bina);
 y = mldivide(binbt, binta);
 binc = ctranspose(y);
 
end % if




