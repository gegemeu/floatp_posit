function binc=conv_binfl(bina,nbits);
%CONV_BINFL conversion to a floating point number with a different value of nbits

% dependencies: binfl2dec, f_d_round_bin

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(bina);

binc = bina;

for i = 1:na
 for j = 1:ma
  binc(i,j) = convfl(bina(i,j),nbits);
 end % for j
end % for i

end % function

function binout=convfl(bin,nbits)

nb = bin.nbits;
binout = bin;

if nbits >= nb
 % pad with zeros
 binout.F = [bin.F zeros(1,nbits-nb)];
 binout.nbits = nbits;
 return
 
else
 % round the fractional part
 binout.F = f_d_round_bin(bin.F,nbits,bin.sign);
 binout.nbits = nbits;
 binout.float = binfl2dec(binout);
 return
 
end % if

end % function