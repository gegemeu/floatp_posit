function X = subsasgn(X,S,Y)
%SUBSASGN for binary floating point

if isa(Y,'floatp')
 Y = binfl2decm(Y);
end % if

Xd = binfl2decm(X);
Xd = subsasgn(Xd,S,Y);
nbits = X(1).nbits;
X = floatp(Xd,nbits);

