function binc = acos(bina);
%ACOS componentwise inverse cosine of a binary floating point number or matrix

% output in radians

% dependencies: acos_binfl

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(bina);

if na == 1 && ma == 1
 binc = acos_binfl(bina);
 
else
 binc = bina;
 [na,ma] = size(bina);
 for i = 1:na
  for j = 1:ma
   binc(i,j) = acos_binfl(bina(i,j));
  end % for j
 end % for j
 
end % if



