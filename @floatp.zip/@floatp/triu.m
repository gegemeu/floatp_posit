function binc=triu(bina,k);
%TRIU upper triangular part of a binary floating point matrix

% dependencies: floatp

%
% Author G. Meurant
% April 2020
%

if nargin == 1
 k = 0;
end % if

binc = bina;

nbits = bina.nbits;

[na,ma] = size(bina);

B = triu(ones(na,ma),k) == 0;

binc(B) = floatp(0,nbits);

