function binc=ceil(bina);
%CEIL ceil for a binary floating point number

% dependencies: floatp, binfl2dec

%
% Author G. Meurant
% April 2020
%

[na,ma] = size(bina);
nbits = bina.nbits;

binc = bina;

for i = 1:na
 for j = 1:ma
  dec = binfl2dec(binc(i,j));
  binc(i,j) = floatp(ceil(dec),nbits);
  
 end % for j
end % for i



