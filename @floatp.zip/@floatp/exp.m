function binc = exp(bina);
%EXP componentwise exponential of a binary floating point number or matrix

% dependencies: exp_binfl

%
% Author G. Meurant
% April 2020
%

[na,ma] = size(bina);

if na == 1 && ma == 1
 binc = exp_binfl(bina);
 
else
 binc = bina;
 [na,ma] = size(bina);
 for i = 1:na
  for j = 1:ma
   binc(i,j) = exp_binfl(bina(i,j));
  end % for j
 end % for j
 
end % if



