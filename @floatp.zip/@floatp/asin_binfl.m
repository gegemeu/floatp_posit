function binc=asin_binfl(bina);
%ASIN_BINFL inverse sine function for a binary floating point number

% dependencies: floatp, binfl2dec, add_binfl, minus_binfl, mul_binfl, div_binfl

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;

dec = binfl2dec(bina);

if abs(dec) > 1
 error(' asin_binfl: the argument must have an absolute value less than or equal to 1')
end % if

if abs(dec) < 2^(-nbits)
 binc = floatp(0,nbits);
 return
end % if

if abs(dec - 1) < 2^(-nbits)
 binc = floatp(pi/2,nbits);
 return
end % if

if abs(dec + 1) < 2^(-nbits)
 binc = floatp(-pi/2,nbits);
 return
end % if

if abs(dec) < 2^(-nbits/2)
 binc = bina;
 return
end % if

pS0 = floatp(1.66666666666666657415e-01,nbits);
pS1 = floatp(-3.25565818622400915405e-01,nbits);
pS2 = floatp(2.01212532134862925881e-01,nbits);
pS3 = floatp(-4.00555345006794114027e-02,nbits);
pS4 = floatp(7.91534994289814532176e-04,nbits);
pS5 = floatp(3.47933107596021167570e-05,nbits);
qS1 = floatp(-2.40339491173441421878e+00,nbits);
qS2 = floatp(2.02094576023350569471e+00,nbits);
qS3 = floatp(-6.88283971605453293030e-01,nbits);
qS4 = floatp(7.70381505559019352791e-02,nbits);

one = floatp(1,nbits);
pis2 = floatp(pi/2,nbits);
two = floatp(2,nbits);

if abs(dec) < 0.5
 
 t = mul_binfl(bina, bina);
 p = mul_binfl(t, add_binfl(pS0, mul_binfl(t, add_binfl(pS1, mul_binfl(t, add_binfl(pS2, mul_binfl(t,...
  add_binfl(pS3, mul_binfl(t, add_binfl(pS4, mul_binfl(t, pS5)))))))))));
 q = add_binfl(one, mul_binfl(t, add_binfl(qS1, mul_binfl(t, add_binfl(qS2, mul_binfl(t, add_binfl(qS3, mul_binfl(t, qS4))))))));
 w = div_binfl(p, q);
 binc =  add_binfl(bina, mul_binfl(bina, w));
 return
 
else
 w = minus_binfl(one, abs(bina));
 t = mul_binfl(w, floatp(0.5,nbits));
 p = mul_binfl(t, add_binfl(pS0, mul_binfl(t, add_binfl(pS1, mul_binfl(t, add_binfl(pS2,...
  mul_binfl(t, add_binfl(pS3, mul_binfl(t, add_binfl(pS4, mul_binfl(t, pS5)))))))))));
 q =  add_binfl(one, mul_binfl(t, add_binfl(qS1, mul_binfl(t, add_binfl(qS2, mul_binfl(t, add_binfl(qS3, mul_binfl(t, qS4))))))));
 s = sqrt_binfl(t);
 
 if abs(dec) > 0.975
  w = div_binfl(p, q);
  t = minus_binfl(pis2, mul_binfl(two, add_binfl(s, mul_binfl(s, w))));
  
 else
  w  = s;
  c  = div_binfl(minus(t, mul_binfl(w, w)) , add_binfl(s, w));
  r  = div_binfl(p, q);
  t = minus_binfl(pis2, mul_binfl(two,  add_binfl(minus_binfl(mul_binfl(s, r), c), w)));
 end % if
 
 binc = t;
 if dec < 0
  binc.sign = 1;
 end % if
 
end % if

