function binc = atan(bina);
%ATAN componentwise inverse tangent of a binary floating point number or matrix

% output in radians

% uses the relation between atan and asin, but this is cheating.......

% dependencies: atan_binfl

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(bina);

if na == 1 && ma == 1
 binc = atan_binfl(bina);
 
else
 binc = bina;
 [na,ma] = size(bina);
 for i = 1:na
  for j = 1:ma
   binc(i,j) = atan_binfl(bina(i,j));
  end % for j
 end % for j
 
end % if



