function binc=inv(bina);
%INV inverse of a binary floating point matrix

% dependencies: floatp_et=ye, div_binfl, \

%
% Author G. Meurant
% April 2020
%

[na,ma] = size(bina);

nbits = bina(1,1).nbits;

if na == 1 && ma == 1
 one = floatp(1,nbits);
 binc = div_binfl(one, bina);
 return
end % if

if na ~= ma
 error(' inv: the matrix must be square')
end % if

binb = floatp_eye(nbits,na,na);

binc = bina \ binb;

