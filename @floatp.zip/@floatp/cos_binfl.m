function binc=cos_binfl(bina);
%COS_BINFL cos function for a binary fixed point number

% dependencies: sin_bfl, minus_binfl, mul_binfl, sqrt_binfl, binfl2dec

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;

s = sin_binfl(bina); % sine

% c = sqrt(1 - s^2);  this is to maintain s^2 + c^2 = 1 to working precision
% if s is close to 1, 1 - s^2 can be negative

one = floatp(1,nbits);
os = minus_binfl( one, mul_binfl(s,s));

if os.float == 0
 binc = floatp(0,nbits);
 return
 
elseif os.float < 0
 os.sign = 0;
 os.float = abs(os.float);
end % if

binc = sqrt_binfl(os); % this is > 0

y = abs(bina);
z = rem(binfl2dec(y),2*pi);

if z > pi/2 && z < 3*pi/2
 binc.sign = ~binc.sign;
 binc.float = -binc.float;
end % if

