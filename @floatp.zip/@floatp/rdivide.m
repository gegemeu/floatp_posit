function binc = rdivide(bina,binb);
%RDIVIDE componentwise division of two binary floating point numbers or matrices
% bina ./ binb

% dependencies: floatp, div_binfl, div_binflm

%
% Author G. Meurant
% May 2020
%

if ~isa(bina,'floatp')
 bina = floatp(bina,binb(1).nbits);
end % if 

if ~isa(binb,'floatp')
 binb = floatp(binb,bina(1).nbits);
end % if 

[na,ma] = size(bina);
[nb,mb] = size(binb);

if na == 1 && ma == 1 && nb ~= 1 && mb ~= 1
 binc = binb;
 for i = 1:nb
  for j = 1:mb
   binc(i,j) = div_binfl(bina,binb(i,j));
  end % for j
 end % for i
 return
end % if
 
if na ~= nb || nb ~= mb
 error(' rdivide: the two inputs must have the same size')
end % if

if na == 1 && ma == 1 && nb == 1 && mb == 1
 binc = div_binfl(bina,binb);
 
else
 binc = div_binflm(bina,binb);
end % if



