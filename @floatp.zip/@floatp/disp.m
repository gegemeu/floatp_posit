function disp(x)
% DISP displays the binary floating point as a double

%
% Author G. Meurant
% May 2020
%

disp(double(x))

