function binc=floor(bina);
%FLOOR floor for a binary floating point number

% dependancies: floatp, binfl2dec, floor (for doubles)

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(bina);
nbits = bina.nbits;

binc = bina;

for i = 1:na
 for j = 1:ma
  dec = binfl2dec(bina(i,j));
  binc(i,j) = floatp(floor(dec),nbits);
  
 end % for j
end % for i



