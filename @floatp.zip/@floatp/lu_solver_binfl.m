function binx=lu_solver_binfl(binb,L,U,p);
%LU_SOLVER_BINFL linear solve for binary floating point

% L U binx = binb(p)

% dependencies: floatp, minus_binfl, div_binfl, dot_binfl

%
% Author G. Meurant
% April 2020
%

nbits = binb(1).nbits;

binb = binb(p);

% solve L y = binb
n = size(L,1);

y = floatp(zeros(n,1),nbits);
y(1) = div_binfl(binb(1), L(1,1));

for k = 2:n
 s = dot_binfl(L(k,1:k-1), y(1:k-1));
%  y(k) = div_binfl(minus_binfl(binb(k), s), L(k,k));
 y(k) = minus_binfl(binb(k), s); % L(k,k) = 1
end % for k

% solve of U binx = y
binx = floatp(zeros(n,1),nbits);
binx(n) = div_binfl(y(n), U(n,n));

for k = n-1:-1:1
 s = dot_binfl(U(k,k+1:n), binx(k+1:n));
 binx(k) = div_binfl(minus_binfl(y(k), s), U(k,k));
end % for k

