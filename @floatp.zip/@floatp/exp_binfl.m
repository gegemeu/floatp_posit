function binc=exp_binfl(bina);
%EXP_BINFL exponential of a binary floating point number

% dependencies: floatp, binfl2dec, round2int, add_binfl, minus_binfl, mul_binfl

%
% Author G. Meurant
% May 2020
%

y = abs(bina);
decp = binfl2dec(bina);
decy = abs(decp);
nbits = bina.nbits;

if decy < 2^(-nbits)
 binc = floatp(1,nbits);
 return
end % if

if decp > 700
 error(' exp_binfl: bina is too large') 
end % if

if decp < 0 && decy > 750
 binc = floatp(0,nbits);
 return
end % if

% ln2 = 0.69314718055994528622676398299518; % log(2)

% ln21 = 1.4426950408889634073599246810018921374; % 1 / log(2)
ln21 = floatp(1.4426950408889634073599246810018921374,nbits);

% c1 = 0.693359375000000000; % 355 / 512
c1 = floatp(0.693359375000000000,nbits);
% c2 = -2.121944400546905827679e-4;
c2 = floatp(-2.121944400546905827679e-4,nbits); % c1 + c2 = log(2)

n = round2int( mul_binfl(bina, ln21)); % round to nearest integer
decn = binfl2dec(n);

g = minus_binfl( (minus_binfl(bina, mul_binfl(n,c1))), mul_binfl(n,c2)); % (p - n * c1) - n * c2;

p1 = floatp(1.66666666666666019037e-01,nbits);
p2 = floatp(-2.77777777770155933842e-03,nbits);
p3 = floatp(6.61375632143793436117e-05,nbits);
p4 = floatp(-1.65339022054652515390e-06,nbits);
p5 = floatp(4.13813679705723846039e-08,nbits); 

t = mul_binfl(g,g); 

% c  = g - t * (p1 + t * (p2 + t * ( p3 + t * (p4 + t * p5) ) ) );
c  = minus_binfl(g, mul_binfl(t, add_binfl(p1, mul_binfl(t, add_binfl(p2, mul_binfl(t,...
 add_binfl(p3, mul_binfl(t, add_binfl(p4, mul_binfl(t,p5) ) ) ) ) ) ) ) ) );

one = floatp(1,nbits);
two = floatp(2,nbits);
y = minus_binfl(one, minus_binfl( div_binfl( mul_binfl(g,c), minus_binfl(c,two) ), g));  % 1 - ( [(g * c) / (c - 2)] - g); 

if decn == 0
 binc = y;
else
 n2 = floatp(2^decn,nbits);
 binc = mul_binfl(y,n2); % ex = y * 2^n
end % if
 
 
 
 
 


