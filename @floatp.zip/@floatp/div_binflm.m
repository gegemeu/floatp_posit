function binc = div_binflm(bina,binb);
%DIV_BINFLM componentwise division of two matrices of binary floating point numbers

% dependencies: div_binfl

%
% Author G. Meurant
% April 2020
%

[rowa,cola] = size(bina); % number of rows and columns
[rowb,colb] = size(binb);
if rowa ~= rowb || cola ~= colb
 error(' div_binflm: incompatible dimensions of inputs')
end % if

% create a binary element and set its parameters
binc = bina;

for i = 1:rowa
 for j = 1:cola
  binc(i,j) = div_binfl(bina(i,j),binb(i,j));
 end % for j
end % for i