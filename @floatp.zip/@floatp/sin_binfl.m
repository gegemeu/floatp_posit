function binc=sin_binfl(bina);
%SIN_BINFL sine function for a binary floating point number

% dependencies: floatp, binfl2dec, round2int, add_binfl, minus_binfl, mul_binfl, floor

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;

dec = binfl2dec(bina);
dec = abs(dec);
dec = mod(dec,2*pi);

if dec <= 2^(-nbits)
 binc = floatp(0,nbits);
 return
end % if

if abs(dec - pi/2) <= 2^(-nbits) 
 binc = floatp(1,nbits);
 return
end % if

if abs(dec - 3*pi/2) <= 2^(-nbits)
 binc = floatp(-1,nbits);
 return
end % if

if abs(dec - pi) <= 2^(-nbits)
 binc = floatp(0,nbits);
 return
end % if

% convert dec back to binary fixed point 
if bina.sign == 1
 dec = -dec;
end % if
bina = floatp(dec,nbits);


pi1 = floatp(0.31830988618379067154,nbits); % 1 / pi

sigp = bina.sign;
if sigp == 0
 sig = 1;
else
 sig = -1;
end % if

y = abs(bina);
n = round2int(mul_binfl(y,pi1));

x1 = floor(y); 
x2 = minus_binfl(y,x1);
c1 = floatp(3217 / 1024,nbits);
c2 = floatp(-8.908910206761537356617e-6,nbits);

f = minus_binfl( add_binfl( minus_binfl(x1, mul_binfl(n,c1)), x2), mul_binfl(n,c2)); % ( (x1 - n * c1) + x2) - n * c2

s1 = floatp(-1.66666666666666324348e-01,nbits);
s2 = floatp(8.33333333332248946124e-03,nbits);
s3 = floatp(-1.98412698298579493134e-04,nbits);
s4 = floatp(2.75573137070700676789e-06,nbits);
s5 = floatp(-2.50507602534068634195e-08,nbits);
s6 = floatp(1.58969099521155010221e-10,nbits);

if binfl2dec(bina) == 0
 binc = floatp(0,nbits);
 return
end % if

fd = binfl2dec(f);
if abs(fd) > 2^(-32)
 
 z = mul_binfl(f,f);
 v =  mul_binfl(z,f);
 r =  add_binfl(s2, mul_binfl(z, add_binfl(s3, mul_binfl(z, add_binfl(s4, mul_binfl(z, add_binfl(s5, mul_binfl(z,s6)))))))); % r =  s2 + z * (s3 + z * (s4 + z * (s5 + z * s6)))
 binc = add_binfl(f, mul_binfl(v ,(add_binfl(s1, mul_binfl(z,r))))); % s = f + v * (s1 + z * r)
 
else
 
 binc = f;
 
end % if

if sig ~= 1
 binc.sign = ~f.sign;
 binc.float = -binc.float;
else
 binc.sign = f.sign;
end % if

if mod(n.float,2) ~= 0
 binc.sign = ~binc.sign;
 binc.float = -binc.float;
end % if


