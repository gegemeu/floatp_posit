function binc=acos_binfl(bina);
%ACOS_BINFL inverse cosine function for a binary floating point number

% dependencies: floatp, asin_binfl, add_binfl, mul_binfl, minus_binfl, sqrt

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;

dec = binfl2dec(bina);

if abs(dec) > 1
 error(' acos_binfl: the argument must have an absolute value less than or equal to 1')
end % if

if abs(dec) < 2^(-nbits)
 binc = floatp(pi/2,nbits);
 return
end % if

if abs(dec - 1) < 2^(-nbits)
 binc = floatp(0,nbits);
 return
end % if

if abs(dec + 1) < 2^(-nbits)
 binc = floatp(pi,nbits);
 return
end % if

one = floatp(1,nbits);
two = floatp(2,nbits);
pif = floatp(pi,nbits);
onehalf = floatp(0.5,nbits);

if dec > 0.5
 binc = mul_binfl(two, asin_binfl(sqrt( mul_binfl(onehalf, minus_binfl(one, bina)))));
 return
end % if

if dec < -0.5
 binc = minus_binfl(pif, mul_binfl(two, asin_binfl(sqrt( mul_binfl(onehalf, add_binfl(one, bina))))));
 return
end % if

pis2 = floatp(pi/2,nbits);
binc = minus_binfl(pis2, asin_binfl(bina));





