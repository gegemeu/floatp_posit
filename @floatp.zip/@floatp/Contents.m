% @FLOATP
%
% Files
%   abs               - absolute value of a binary floating point number
%   acos              - componentwise inverse cosine of a binary floating point number or matrix
%   acos_binfl        - inverse cosine function for a binary floating point number
%   acot              - componentwise inverse tangent of a binary floating point number or matrix
%   acot_binfl        - inverse cotangent function for a binary floating point number
%   add_binf          - addition of two fixed point binary numbers
%   add_binfl         - addition of two binary floating point numbers
%   add_binflm        - addition of two matrices of binary floating point numbers
%   asin              - componentwise inverse sine of a binary floating point number or matrix
%   asin_binfl        - inverse sine function for a binary floating point number
%   atan              - componentwise inverse tangent of a binary floating point number or matrix
%   atan_binfl        - inverse tangent function for a binary floating point number
%   bin2frac          - converts the input array to a fractional part
%   binary            - outputs the fields of a floating point number
%   binfl2dec         - binary floating point to double matrix
%   binfl2decm        - binary floating point to double matrix
%   binfl_inv_Newton  - computation of binary fixed point 1/d by Newton iteration with normalization
%   ceil              - ceil for a binary floating point number
%   conv_binfl        - conversion to a floating point number with a different value of nbits
%   cos               - componentwise cosine of a binary floating point number or matrix
%   cos_binfl         - cos function for a binary fixed point number
%   cot               - componentwise cotangent of a binary floating point number or matrix
%   cot_binfl         - cotangent function for a binary floating point number
%   ctranspose        - transpose of a (real) binary floating point matrix
%   diag              - diagonal function for a binary floating point matrix or vector
%   disp              - displays the binary floating point as a double
%   display           - display for a binary floating point number
%   div_binfl         - division of binary floating point numbers diva / divb
%   div_binflm        - componentwise division of two matrices of binary floating point numbers
%   div_binflms       - division of a matrix by a scalar, binary floating point numbers
%   dot_binfl         - dot product of two binary floating point vectors
%   double            - double precision value of binary floating point bin
%   exp               - componentwise exponential of a binary floating point number or matrix
%   exp_binfl         - exponential of a binary floating point number
%   find_min_max      - finds the first and last significand bits in bin
%   fix               - fix for binary floating point numbers
%   floatp            - constructor for the class floatp, binary floating point arithmetic
%   floatp2quire      - converts a floating point number to a quire structure
%   floor             - floor for a binary floating point number
%   inv               - inverse of a binary floating point matrix
%   iszero_binf       - returns true (1) if the floating point binary number is zero
%   ldivide           - binb .\ bina
%   log               - componentwise natural logarithm of a binary floating point number or matrix
%   log10             - componentwise base 10 logarithm of a binary fixed point number or matrix
%   log_binfl         - natural logarithm of a floating point number
%   lu                - triangular factorization, floating point numbers
%   lu_solver_binfl   - linear solve for binary floating point
%   mat_prod_binfl    - floating point matrix-matrix product
%   minus             - subtraction of two binary floating point numbers or matrices
%   minus_binf        - subtraction of two fixed point binary numbers, bina - binb
%   minus_binfl       - subtraction of two binary floating point numbers
%   minus_binflm      - subtraction of two matrices of binary floating point numbers
%   mldivide          - division of two binary floating point numbers or matrices
%   mpower            - bina ^ p for floating point numbers
%   mrdivide          - division of two binary floating point numbers or matrices
%   mtimes            - product of two binary floating point numbers or matrices
%   mul_binf          - product of two fixed point numbers
%   mul_binfl         - multiplication of two binary floating point numbers
%   mul_binflm        - componentwise multiplication of two matrices of binary floating point numbers
%   mul_binflo        - outer product of two vectors of binary floating point numbers
%   mul_binflsm       - scalar-matrix product for floating point binary numbers
%   norm              - Frobenius norm of a binary floating point matrix
%   plus              - addition of two binary floating point numbers or matrices
%   pow2              - power of 2 in seed 
%   power             - bina .^ p for floating point numbers
%   printfloatp       - prints the fields of binary floating point
%   prod              - prod of vector or matrix binary floating point numbers
%   rdivide           - componentwise division of two binary floating point numbers or matrices
%   right_shift_binfl - shift to the right by k places
%   round2int         - round the binary floating point number to the nearest integer
%   sin               - componentwise sine of a binary floating point number or matrix
%   sin_binfl         - sine function for a binary floating point number
%   sqrt              - componentwise square root of a binary floating point number or matrix
%   sqrt_binfl        - square root of a binary floating point number
%   subsasgn          - for binary floating point
%   subsref           - for binary floating point
%   sum               - sum of vector or matrix binary floating point numbers
%   tan               - componentwise tangent of a binary floating point number or matrix
%   tan_binfl         - tangent function for a binary floating point number
%   times             - componentwise product of two binary floating point numbers or matrices
%   trace             - trace of a binary floating point matrix
%   tril              - lower triangular part of a binary floating point matrix
%   triu              - upper triangular part of a binary floating point matrix
%   uminus            - change signs of bina
%   uplus             - does not change signs of bina
