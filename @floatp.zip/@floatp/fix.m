function binc=fix(bina);
%FIX fix for binary floating point numbers

% dependencies: floor, ceil

%
% Author G. Meurant
% May 2020
%

sig = bina.sign;

if sig == 0
 binc = floor(bina);
 return
end %

binc = ceil(bina);

