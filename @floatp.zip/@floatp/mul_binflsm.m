function bincm = mul_binflsm(bina,binbm);
%MUL_BINFLSM scalar-matrix product for floating point binary numbers

% bina is a scalar and binbm is a matrix

% bina and binbm must have the same parameters

% dependencies: f_d_mul

%
% Author G. Meurant
% May 2020
%

nbitsa = bina.nbits;
nbitsb = binbm.nbits;
if nbitsa ~= nbitsb
 error(' mul_binflsm: the two binary elements must have the same parameters')
end % if

bincm = binbm;
[row,col] = size(binbm);

for i = 1:row
 for j = 1:col
  bincm(i,j) = mul_binfl(bina,binbm(i,j));
 end % for j
end % for i



