function x = double(bin);
%DOUBLE double precision value of binary floating point bin

% dependencies: binfl2dec, binfl2decm

%
% Author G. Meurant
% May 2020
%

[n,m]= size(bin);

if n == 1 && m == 1
 x = binfl2dec(bin);
else
 x = binfl2decm(bin);
end % if

