function binc = div_binflms(bina,binb);
%DIV_BINFLMS division of a matrix by a scalar, binary floating point numbers

% bina / binb, binb is a scalar

% dependencies: div_binfl

%
% Author G. Meurant
% May 2020
%

[rowa,cola] = size(bina); % number of rows and columns
[rowb,colb] = size(binb);
if rowb ~= 1 || colb ~= 1
 error(' div_binflms: binb must be a scalar')
end % if

% Create a binary element and set its parameters
binc = bina;

for i = 1:rowa
 for j = 1:cola
  binc(i,j) = div_binfl(bina(i,j),binb);
 end % for j
end % for i

