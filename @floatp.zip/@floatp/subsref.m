function Z = subsref(X,S)
%SUBSREF for binary floating point

if isequal(S.type,'.')
 Z = X;
else
 nbits = X.nbits;
 Z = floatp(subsref(double(X),S),nbits);
end

