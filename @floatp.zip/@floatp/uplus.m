function binc = uplus(bina);
%UPLUS does not change signs of bina

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(bina);

binc = bina;

