function binc=trace(bina);
%TRACE trace of a binary floating point matrix

% dependencies: diag, sum

%
% Author G. Meurant
% May 2020
%

d = diag(bina);
binc = sum(d);

