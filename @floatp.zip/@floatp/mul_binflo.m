function binc = mul_binflo(bina,binb);
%MUL_BINFLO outer product of two vectors of binary floating point numbers

% Both inputs must have the same parameters (nbits and es). The result will also have
% the same parameters

% dependencies: mul_binfl

%
% Author G. Meurant
% May 2020
%

nbits = min(bina(1).nbits,binb(1).nbits);

[rowa,cola] = size(bina); % number of rows and columns
[rowb,colb] = size(binb);

if cola ~= 1
 bina = bina';
end % if

if rowb ~= 1
 binb = binb';
end % if

% Create a binary element and set its parameters
binc = floatp(zeros(rowa,colb),nbits);

for i = 1:rowa
 for j = 1:colb
  binc(i,j) = mul_binfl(bina(i),binb(j));
 end % for j
end % for i