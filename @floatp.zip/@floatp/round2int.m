function binc=round2int(bina);
%ROUND2INT round the binary floating point number to the nearest integer

% dependencies: floatp, binfl2dec

%
% Author G. Meurant
% May 2020
%

[na,ma] = size(bina);
nbits = bina.nbits;

binc = bina;

for i = 1:na
 for j = 1:ma
  dec = binfl2dec(bina(i,j));
  binc(i,j) = floatp(round(dec),nbits);
  
 end % for j
end % for i


   
  