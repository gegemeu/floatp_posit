
@floatp

 class for operations on binary floating point numbers of arbitrary precision

 uses some functions in f_d_floatp

 due to the overhead of class management, this is slower than directly using the
 functions in f_d_floatp but one can use +,-, *, / as usual on scalar and matrices

 some elementary functions as sin, cos, exp, log are also implemented

 it is distributed without any warranty

 G. Meurant
 May 2020

