function [L,U,P,p] = lu(A);
%LU  triangular factorization, floating point numbers

% [L,U,P] = lu(A) produces a unit lower triangular matrix L,
%  an upper triangular matrix U, and a permutation vector p, so that L*U = P * A

% p is the permutation vector corresponding to P

% dependencies: binfl2dec, binfl2decm, div_binflms, minus_binflm, mul_binflo, add_binflm,
%               floatp_eye, triu

[n,n] = size(A);
p = (1:n)';

nbits = A.nbits;

for k = 1:n-1
 
 % find index of largest element below diagonal in kth column
 [~,m] = max(abs(binfl2decm(A(k:n,k)))); 
 m = m + k - 1;
 
 % skip elimination if column is zero
 if binfl2dec(A(m,k)) ~= 0
  
  % Swap pivot row
  if m ~= k
   A([k m],:) = A([m k],:);
   p([k m]) = p([m k]);
  end
  
  % compute multipliers
  i = k+1:n;
  A(i,k) = div_binflms(A(i,k), A(k,k)); % division of a vector by a scalar
  
  % update the remainder of the matrix
  j = k+1:n;
  A(i,j) = minus_binflm(A(i,j), mul_binflo(A(i,k), A(k,j))); % subtraction of an outer product
 end % if
end % for k

% Separate result
I = floatp_eye(nbits,n);
L = add_binflm(tril(A,-1), I); 
U = triu(A);

% construct P 
P = I(:,p);
