function s = dot_binfl(binav,binbv);
%DOT_BINFL dot product of two binary floating point vectors

% the result may not be accurate. If not use an accumulator

% binav and binbv must have the same parameters

% dependencies: floatp, mul_binfl, add_binfl

%
% Author G. Meurant
% March 2020
%

na = length(binav);
nb = length(binbv);
if na ~= nb
 error(' dot_binfl: the two binary vectors must have the same length')
end % if

nbitsa = binav.nbits;
nbitsb = binbv.nbits;
if nbitsa ~= nbitsb
 error(' dot_binfl: the two binary vectors must have the same parameters')
end % if

s = floatp(0,nbitsa); % s = 0

for k = 1:na
 product = mul_binfl(binav(k),binbv(k));
 s = add_binfl(s,product);
end % for k

