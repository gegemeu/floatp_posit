function bin = floatp(x,nbits);
%FLOATP constructor for the class floatp, binary floating point arithmetic

% x is a double precision scalar or matrix

% bin is a structure with fields: sign, I, F, E, float, nbits
% I and F are the (binary) integer and fractional (significand) parts, E is the (double) exponent
% float is the corresponding (rounded) double value
% nbits is the number of bits of the fractional part

% dependencies: f_d_dec2floatp

%
% Author G. Meurant
% April 2020
%

global round_mode
global bits_expo

if isa(x,'floatp')
 bin = x;
 return
end % if

if isempty(round_mode)
 round_mode = 1;
end % if

if isempty(bits_expo)
 bits_expo = 0;
end % if

% if ~isfloat(x)
%  error(' floatp: the input must be a double or a floatp')
% end % if

% [n,m] = size(x);
% 
% if (n == 1 && m == 1) || isempty(x) 
%  bin = f_d_dec2floatp(x,nbits);
%  bin = class(bin,'floatp');
%  
% else
%  bin = f_d_dec2floatp(x,nbits);
%  bin = class(bin,'floatp');
% end % if

bin = f_d_dec2floatp(x,nbits);
bin = class(bin,'floatp');



