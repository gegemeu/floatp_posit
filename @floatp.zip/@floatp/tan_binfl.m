function binc=tan_binfl(bina);
%TAN_BINFL tangent function for a binary floating point number

% dependencies: floatp, binfl2dec, sin_binfl, cos_binfl, div_binfl

% uses tan = sin / cos, but this is cheating.......

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;

dec = binfl2dec(bina);
dec = abs(dec);
dec = mod(dec,2*pi);

if abs(dec - pi/2) < 2^(-nbits)
 fprintf(' tan_binfl: caution, the tangent is large, may be Inf \n')
 binc = floatp(1e300,nbits); % ???????
 return
end % if

if abs(dec - 3*pi/2) < 2^(-nbits)
 fprintf(' tan_binfl: caution, the tangent is large, may be -Inf \n')
 binc = floatp(-1e300,nbits); % ???????
 return
end % if

binc = div_binfl(sin_binfl(bina), cos_binfl(bina));

