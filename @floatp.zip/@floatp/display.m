function display(x);
%DISPLAY display for a binary floating point number

%
% Author G. Meurant
% May 2020
%

disp(' ');
disp([inputname(1),' = '])
disp(' ');
disp(double(x))
disp(' ');
