function q=floatp2quire(bina);
%FLOATP2QUIRE converts a floating point number to a quire structure

%
% Author G. Meurant
% May 2020
%

% compute the exponent (of 2) for bina
texp = bina.E;

nbits = bina.nbits;

nq = nbits^2 / 4 - nbits / 2; % this is the standard
nc = nbits - 1;

sig = bina.sign;
x = bina.float;
I = bina.I; % hidden bit
F = bina.F;
C = zeros(1,nc);

if texp ~= 0
 % we have to shift
 if texp < 0 % shift right
  I = [0];
  F = [zeros(1,abs(texp)-1) F];
 else % shift left
  I = [I F(1:texp)];
  F = F(texp+1:end);
 end % if
end % if texp

lI = length(I);

if lI < nq 
 % pad with zeros
 I = [zeros(1,nq-lI) I];
 
else
 % a part of I goes to C
 C = I(1:lI-nq);
 I = I(lI-nq+1:end);
 lC = length(C);
 if lC > nc
  error(' floatp2quire: the number of bits needed for the input is too large for the quire')
 else
  C = [zeros(1,nc-lC) C];
 end % if lC
end % if lI

F = [F zeros(1,nq-length(F))];
  
q = struct('sign',sig,'C',C,'I',I,'F',F,'float',x,'nq',nq,'nc',nc,'nbits',nbits);

% q = quire(q);




