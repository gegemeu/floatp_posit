function binc=atan_binfl(bina);
%ATAN_BINFL inverse tangent function for a binary floating point number

% dependencies: add_binfl, mul_binfl, div_binfl, sqrt_binfl, asin_binfl

% uses the relation between atan and asin, but this is cheating.......

%
% Author G. Meurant
% May 2020
%

nbits = bina.nbits;
one = floatp(1,nbits);

den = sqrt_binfl( add_binfl(one, mul_binfl(bina, bina)));

binc = asin_binfl( div_binfl(bina, den));

