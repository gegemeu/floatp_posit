
f_d_floatp

 Set of functions for operations on binary floating point numbers of arbitrary precision

 Some of these functions are used in class @floatp

 Some testing functions for the basic operations are in Checks

 Examples of use on CG algorithm are in Examples

 It is distributed without any warranty

 G. Meurant
 May 2020

