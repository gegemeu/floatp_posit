function [x,y,diff,dadd,decbadd]=check_f_d_dot(m,n,mul,nbits,x,y);
%CHECK_F_D_DOT checks the binary floating point dot product

% m is the length of the vectors, n the number of random checks

% dependencies: f_d_dec2floatp, f_d_dot, f_d_floatp2dec

%
% Author G. Meurant
% May 2020
%

if nargin <= 4
 x = randn(m,n);
 y = mul * randn(m,n);
end % if

diff = zeros(n,1);
dadd = zeros(n,1);
decbadd = zeros(n,1);

for k = 1:n
 bx = f_d_dec2floatp(x(:,k),nbits);
 by = f_d_dec2floatp(y(:,k),nbits);
 
 badd = f_d_dot(bx,by);

 decbadd(k) = f_d_floatp2dec(badd);
 
 dadd(k) = x(:,k)' * y(:,k);
 
 diff(k) = abs(dadd(k) - decbadd(k)) ./ abs(dadd(k));
 
end % for k

semilogy(diff)

