% CHECKS
%
% Files
%   check_f_d_add      - checks the binary floating point addition
%   check_f_d_conv     - checks the binary floating point conversion from double
%   check_f_d_div      - checks the binary floating point division
%   check_f_d_dot      - checks the binary floating point dot product
%   check_f_d_mat_prod - checks the binary floating point matrix-vector product
%   check_f_d_minus    - checks the binary floating point subtraction
%   check_f_d_mul      - checks the binary floating point multiplication
%   check_f_d_sqrt     - checks the binary floating point square root
