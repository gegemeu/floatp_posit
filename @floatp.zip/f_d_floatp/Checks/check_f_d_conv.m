function [x,diff,decbadd]=check_f_d_conv(n,mul,nbits,x);
%CHECK_F_D_CONV checks the binary floating point conversion from double

% dependencies: f_d_dec2floatp, f_d_floatp2dec

%
% Author G. Meurant
% May 2020
%

if nargin <= 3
 x = mul * randn(n,1);
end % if

bx = f_d_dec2floatp(x,nbits);

decbadd = f_d_floatp2dec(bx);

diff = abs(x - decbadd) ./ abs(x);

semilogy(diff)

ind = find(diff>1e-2);

if ~isempty(ind)
 fprintf(' x = %20.10e, dec floatp = %20.10e \n',x(ind(1)),decbadd(ind(1)))
end % if




