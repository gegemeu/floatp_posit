function [x,diff,decbadd]=check_f_d_sqrt(n,mul,nbits,x);
%CHECK_F_D_SQRT checks the binary floating point square root

% dependencies: f_d_dec2floatp, f_d_sqrt, f_d_floatp2dec

%
% Author G. Meurant
% May 2020
%

%
% Author G. Meurant
% May 2020
%

if nargin <= 3
 x = mul * randn(n,1);
end % if

badd = f_d_dec2floatp(zeros(1,n),nbits);
decbadd = zeros(1,n);
dadd = zeros(1,n);
diff = zeros(1,n);

x = abs(x);

bx = f_d_dec2floatp(x,nbits);

for k = 1:n
 badd(k) = f_d_sqrt(bx(k));
 decbadd(k) = f_d_floatp2dec(badd(k));
 
 dadd(k) = sqrt(x(k));
 
 diff(k) = abs(dadd(k) - decbadd(k)) ./ abs(dadd(k));
 
end % for k

semilogy(diff)

