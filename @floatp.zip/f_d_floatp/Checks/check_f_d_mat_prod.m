function [x,diff]=check_f_d_mat_prod(A,n,mul,nbits,x);
%CHECK_F_D_MAT_PROD checks the binary floating point matrix-vector product

% dependencies: f_d_floatp2dec, f_d_mat_prod(b), f_d_floatp2dec

%
% Author G. Meurant
% May 2020
%

diff = zeros(1,n);
m = size(A,2);

if nargin <= 4
 x = mul * randn(m,n);
end % if

bx = f_d_dec2floatp(x,nbits);

bA = f_d_dec2floatp(A,nbits);

for k = 1:n
%  Ax = f_d_mat_prod(bA,bx(:,k));
 Ax = f_d_mat_prod_b(A,bA,bx(:,k));
 decAx = f_d_floatp2dec(Ax);
 
 tAx = A * x(:,k);
 
 diff(k) = norm(tAx - decAx) / norm(tAx);
 
end % for k

semilogy(diff)

