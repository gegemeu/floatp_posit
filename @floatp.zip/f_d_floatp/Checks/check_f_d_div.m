function [x,y,diff,decbadd]=check_f_d_div(n,mul,nbits,x,y);
%CHECK_F_D_DIV checks the binary floating point division

% dependencies: f_d_dec2floatp, f_d_divm, f_d_floatp2dec

%
% Author G. Meurant
% May 2020
%

if nargin <= 3
 x = randn(n,1);
 y = mul * randn(n,1);
end % if

bx = f_d_dec2floatp(x,nbits);
by = f_d_dec2floatp(y,nbits);

badd = f_d_divm(bx,by);
decbadd = f_d_floatp2dec(badd);

dadd = x ./ y;

diff = abs(dadd - decbadd) ./ abs(dadd);

semilogy(diff)

