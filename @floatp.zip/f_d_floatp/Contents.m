% F_D_FLOATP
%
% Files
%   d_float_dec2floatp    - converts a double x to binary floating point format
%   f_d_abs               - absolute value of a binary floating point number
%   f_d_add               - addition of two binary floating point numbers
%   f_d_add_bin_carry     - addition of two unsigned binary strings with a carry in
%   f_d_add_bin_one_carry - add 1 to the binary number a
%   f_d_add_binfp         - addition of two fixed point binary numbers
%   f_d_add_floatp2quire  - addition of a floatp bina and a quire qb towards a quire
%   f_d_add_quire         - addition of two quires qa + qb
%   f_d_addbin            - addition of two binary strings (positive integers)
%   f_d_addm              - addition of two matrices of binary floating point numbers
%   f_d_bin2dec           - converts the binary input array to a decimal (double) number
%   f_d_bin2frac          - converts the input array to a double fractional part
%   f_d_bin2str           - bin to string
%   f_d_binary            - prints the fields of a floating point structure
%   f_d_dec2bin           - converts a decimal to binary
%   f_d_dec2floatp        - double to binary floating point matrix
%   f_d_dec2quire         - conversion of a float (double) to a quire
%   f_d_diag              - diagonal function for a binary floating point matrix or vector
%   f_d_div               - division of binary floating point numbers diva / divb
%   f_d_divm              - componentwise division of two matrices of binary floating point numbers
%   f_d_divms             - division of a matrix by a scalar, binary floating point numbers
%   f_d_dot               - dot product of two binary floating point vectors
%   f_d_dot_prod          - dot product of two floatp vector structures using a quire
%   f_d_double            - decimal value of fa
%   f_d_eye               - identity matrix of binary floating point numbers
%   f_d_find_min_max      - find the first and last significand bits in bin
%   f_d_floatp2dec        - binary floating point to double matrix
%   f_d_floatp2quire      - converts a floatp structure to a quire
%   f_d_frac2bin          - converts a fractional part to binary with nbits
%   f_d_init_bits_expo    - initializes the number of bits of the exponents for floatp
%   f_d_init_floatp       - construction a floatp structure from its elements
%   f_d_init_round        - initializes the rounding mode
%   f_d_inv               - inverse of a binary floating point matrix
%   f_d_inv_Newton        - computation of binary floating point 1/d by Newton iteration with normalization
%   f_d_isge_bin          - true if a >= b
%   f_d_iszero            - returns true (1) if the floating point binary number is zero
%   f_d_lu                - triangular factorization, floating point numbers
%   f_d_lu_solver         - linear solver for binary floating point
%   f_d_mat_prod          - floating point matrix-matrix product
%   f_d_mat_prod_b        - floating point matrix-matrix product
%   f_d_minus             - subtraction of two binary floating point numbers
%   f_d_minus_bin         - subtraction of two binary strings (positive integers)
%   f_d_minus_binf        - subtraction of two fixed point binary numbers, bina - binb
%   f_d_minus_binfp       - subtraction of two fixed point binary numbers, bina - binb
%   f_d_minus_quire       - subtraction of two quires, bina - binb
%   f_d_minusm            - subtraction of two matrices of binary floating point numbers
%   f_d_mul               - multiplication of two binary floating point numbers
%   f_d_mul_binf          - product of two fixed point numbers
%   f_d_mulm              - componentwise multiplication of two matrices of binary floating point numbers
%   f_d_mulo              - outer product of two vectors of binary floating point numbers
%   f_d_mulsm             - scalar-matrix product for floating point binary numbers
%   f_d_printfloatp       - prints the fields of a binary floating point
%   f_d_prod              - product of vector or matrix binary floating point numbers
%   f_d_quire2dec         - converts a quire to decimal
%   f_d_quire2floatp      - convert a quire structure to a floatp structure with same nbits
%   f_d_right_shift       - shift bina to the right by k places
%   f_d_round_bin         - round the binary number bin to nbits
%   f_d_sqrt              - square root of a binary floating point number
%   f_d_sum               - sum of vector or matrix binary floating point numbers
%   f_d_tril              - lower triangular part of a binary floating point matrix
%   f_d_triu              - upper triangular part of a binary floating point matrix
%   fix_binf2dec          - converts a fixed point binary number (structure) to a float (double)
%   fix_dec2binf          - converts a double float to binary fixed point
%   fix_dec2binfm         - double to binary fixed point matrix
%   fix_float2binfb       - conversion of a float (double) to fixed point binary
%   floatp_eye            - identity matrix of binary floating point numbers
%   print_round_mode      - prints the rounding mode
