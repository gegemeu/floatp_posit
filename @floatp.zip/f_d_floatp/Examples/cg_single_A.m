function [x,resn,resnt,errn,errnl2,nit]=cg_single_A(A,b,x0,xec,epsi,nitmax);
%CG_SINGLE_A CG for A x = b

% single precision

% A = matrix
% b = rhs, x0 = initial vector
% xec = "exact" solution
% epsi = stopping criterion threshold
% nitmax  = number of iterations

%
% Author G. Meurant
% April 2020
%  

A = single(A);
b = single(b);
x0 = single(x0);
xec = single(xec);

r = b - A * x0; % initial residual vector
errn = single(zeros(1,nitmax+1));
errnl2 = single(zeros(1,nitmax+1));
resn = single(zeros(1,nitmax+1));
resnt =single( zeros(1,nitmax+1));
err = x0 - xec; % initial error
x = x0;
errn(1) = sqrt(err' * (A * err));
errnl2(1) = sqrt(err' * err);
res = r' * r;
resn(1) = norm(r);
resnt(1) = resn(1);
nr = resn(1);
p = r;
rtr = res;
nb = norm(b);
nit = 0;

while (nit < nitmax) && (nr > epsi * nb)
 nit = nit + 1;
 Ap = A * p; % Ap = A * p
 pAp = p' * Ap;

 alp = rtr / pAp;
 
 x = x + alp * p;
 r = r - alp * Ap;
 
 rk = r' * r;
 
 err = x - xec; % error
 errn(nit+1) = sqrt(err' * (A * err)); % norm of the error
 errnl2(nit+1) = sqrt(err' * err);
 resn(nit+1) = norm(r); % norm of the computed residual
 rt = b - A * x;
 resnt(nit+1) = norm(rt); % norm of the true residual

 bet = rk / rtr;
 rtr = rk;
 p = r + bet * p;
 
end % while



