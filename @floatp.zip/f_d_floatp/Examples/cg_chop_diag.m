function [x,resn,resnt,errn,errnl2,nit]=cg_chop_diag(A,b,x0,xex,epsi,nitmax,format,rounding);
%CG_CHOP_DIAG CG for a diagonal matrix A 

% uses the chop class (@chop)

% note that this more expensive than directly using N. Higham's chop_H function

% A must be a vector (diag of the matrix)
% b = rhs, x0 = initial vector
% xex = "exact" solution
% epsi = stopping criterion threshold
% nitmax  = number of iterations
% nbits = size of the significand (fractional part)
% rounding = rounding mode (1,...,6)

% the inputs are double precision numbers

%
% Author G. Meurant
% May 2020
%  

rng('default') % for stochastic rounding

if nargin < 7
 format = 'd';
end % if

if nargin < 8
 rounding = 1;
end % if

subnormal = 1;
flip = [];
explim = [];
params = [52,1023];

opt = init_chop(format,subnormal,rounding,flip,explim,params); % initialize chop parameters

% convert inputs to chops
bA = chop(A,opt);
bb = chop(b,opt);
bx = chop(x0,opt);
xec = chop(xex,opt); % "exact solution"

r = bb - bA .* bx; % initial residual vector

errn = zeros(1,nitmax+1); % double precision values
errnl2 = zeros(1,nitmax+1);
resn = zeros(1,nitmax+1);
resnt = zeros(1,nitmax+1);
err = bx - xec; % initial error

er = err' * (bA .* err); 

% errn(1) = sqrt(double(er)); 
errn(1) = double(sqrt(er)); 
errnl2(1) = double(sqrt(err' * err));

res = r' * r; 

% resn(1) = sqrt(double(res)); 
resn(1) = double(sqrt(res));
resnt(1) = resn(1);
nr = resn(1);

p = r;
rtr = res;
dbb = bb' * bb; 
% nb = sqrt(double(dbb));
nb = double(sqrt(dbb));
nit = 0;

while (nit < nitmax) && (nr > epsi * nb)
 nit = nit + 1;
%  fprintf(' iteration %d \n',nit)
 Ap = bA .* p; % Ap = A * p
 
 pAp = p' * Ap; 
   
 alp = rtr / pAp;
 
 bx = bx + alp * p; % x = x + alp * p
 
 r = r - alp * Ap;
 
 rk = r' * r;

 err = bx - xec;  % error
 er = err' * (bA .* err); 
%  errn(nit+1) = sqrt(double(er)); % norm of the error
 errn(nit+1) = double(sqrt(er)); % norm of the error
 errnl2(nit+1) = double(sqrt(err' * err));
 
 res = rk; 
 
%  resn(nit+1) = sqrt(double(res)); % norm of the computed residual
 resn(nit+1) = double(sqrt(res)); % norm of the computed residual

 rt = bb - bA .* bx;  % "true" residual
 
 res = rt' * rt; 
 
%  resnt(nit+1) = sqrt(double(res)); % norm of the true residual
 resnt(nit+1) = double(sqrt(res)); % norm of the true residual
 
 bet = rk / rtr;
  
 rtr = rk;
 
 p = r + bet * p;
 
end % while

x = double(bx);


