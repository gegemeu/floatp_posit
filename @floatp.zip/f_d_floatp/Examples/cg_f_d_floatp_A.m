function [x,resn,resnt,errn,errnl2,nit]=cg_f_d_floatp_A(A,b,x0,xex,epsi,nitmax,nbits,rounding,expo);
%CG_F_D_FLOATP_A CG for a matrix A of floating point binary numbers

% uses functions of f_d_floatp

% A = matrix
% b = rhs, x0 initial vector
% xex = "exact" solution
% epsi = stopping criterion threshold
% nitmax  = number of iterations
% nbits = size of the significand (fractional part)
% rounding = rounding mode (1,...,6)
% expo = number of bits of the exponent, if = 0 no limitation

% the inputs are double precision numbers

%
% Author G. Meurant
% May 2020
%

rng('default') % for stochastic rounding

if nargin < 9
 expo = 0;
end % if

f_d_init_bits_expo(expo);

if nargin < 8
 rounding = 1;
end % if

f_d_init_round(rounding); % initialize the rounding mode

% convert inputs to binary floating point
bA = f_d_dec2floatp(A,nbits);
bb = f_d_dec2floatp(b,nbits);
bx = f_d_dec2floatp(x0,nbits);
xec = f_d_dec2floatp(xex,nbits); % "exact solution"

bAx = f_d_mat_prod_b(A,bA,bx);
r = f_d_minusm(bb,bAx); % initial residual vector

errn = zeros(1,nitmax+1); % double precision values
errnl2 = zeros(1,nitmax+1);
resn = zeros(1,nitmax+1);
resnt = zeros(1,nitmax+1);
err = f_d_minusm(bx,xec); % initial error

bAe = f_d_mat_prod_b(A,bA,err);
er = f_d_dot(err,bAe);
errn(1) = sqrt(f_d_floatp2dec(er));
% errn(1) = f_d_floatp2dec(f_d_sqrt(er));

er = f_d_dot(err,err);
errnl2(1) = sqrt(f_d_floatp2dec(er));
% errnl2(1) = f_d_floatp2dec(f_d_sqrt(er));

res = f_d_dot(r,r);

resn(1) = sqrt(f_d_floatp2dec(res));
% resn(1) = f_d_floatp2dec(f_d_sqrt(res));
resnt(1) = resn(1);
nr = resn(1);

p = r;
rtr = res;
dbb = f_d_dot(bb,bb);
nb = sqrt(f_d_floatp2dec(dbb));
nit = 0;


while (nit < nitmax) && (nr > epsi * nb)
 nit = nit + 1;
 fprintf(' iteration %d \n',nit)
 Ap = f_d_mat_prod_b(A,bA,p); % Ap = A * p
 
 pAp = f_d_dot(p,Ap); % pAp = p' * Ap
 
 [alp,flag] = f_d_div(rtr,pAp); % alp = rtr / pAp
 
 if flag == 1
  x = f_d_floatp2dec(bx);
  resn = resn(1:nit);
  resnt = resnt(1:nit);
  errn = errn(1:nit);
  return
 end % if
 
 bx = f_d_addm(bx,f_d_mulsm(alp,p)); % x = x + alp * p
 
 r = f_d_minusm(r,f_d_mulsm(alp,Ap)); % r = r - alp * Ap
 
 rk = f_d_dot(r,r); % rk = r' * r
 
 err = f_d_minusm(bx,xec); % error
 bAe = f_d_mat_prod_b(A,bA,err);
 er = f_d_dot(err,bAe);
 errn(nit+1) = sqrt(f_d_floatp2dec(er)); % norm of the error
 %  errn(nit+1) = f_d_floatp2dec(f_d_sqrt_binfl(er));
 
 er = f_d_dot(err,err);
 errnl2(nit+1) = sqrt(f_d_floatp2dec(er));
 %  errnl2(nit+1) = f_d_floatp2dec(f_d_sqrt(er));
 
 res = f_d_dot(r,r);
 
 resn(nit+1) = sqrt(f_d_floatp2dec(res)); % norm of the computed residual
 %  resn(nit+1) = f_d_floatp2dec(f_d_sqrt(res));
 
 bAx = f_d_mat_prod_b(A,bA,bx);
 rt = f_d_minusm(bb,bAx);
 
 res = f_d_dot(rt,rt);
 
 resnt(nit+1) = sqrt(f_d_floatp2dec(res)); % norm of the true residual
 %  resnt(nit+1) = f_d_floatp2dec(f_d_sqrt(res));
 
 [bet,flag] = f_d_div(rk,rtr); % bet = rk / rtr
 
 if flag == 1
  x = f_d_floatp2dec(bx);
  resn = resn(1:nit+1);
  resnt = resnt(1:nit+1);
  errn = errn(1:nit+1);
  return
 end
 
 rtr = rk;
 
 p = f_d_addm(r,f_d_mulsm(bet,p)); % p = r + bet * p
 
end % while

x = f_d_floatp2dec(bx);


