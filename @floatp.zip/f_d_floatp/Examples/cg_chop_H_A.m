function [x,resn,resnt,errn,errnl2,nit]=cg_chop_H_A(A,b,x0,xex,epsi,nitmax,format,rounding,nbit);
%CG_CHOP_H_A CG for a matrix A

% uses Nick Higham's chop_H function

% no preconditioning

% A = matrix
% b = rhs, x0 = initial vector
% xex = "exact" solution
% epsi = stopping criterion threshold
% nitmax  = number of iterations
% nbits = size of the significand (fractional part)
% format = 'b' (bfloat16), 'h' (fp16), 's' (fp32), 'd' (fp64)
% rounding = rounding mode 1,2,...,6

% the inputs are double precision numbers

% we explicitly use the chop_H function and not the chop class

%
% Author G. Meurant
% May 2020
%  

rng('default') % for stochastic rounding

if nargin < 7
 format = 'd';
end % if

if nargin < 8
 rounding = 1; % round to nearest
end % if

if nargin < 9
 nbit = [];
end

subnormal = 1;
% subnormal = 0;
flip = [];
explim = [];
params = [24,1023];

if ~isempty(nbit)
 params = [nbit,1023];
else
 params = [24,1023];
end

opt = init_chop(format,subnormal,rounding,flip,explim,params); % initialize chop parameters

% convert inputs to chops
bA = chop_H(A,opt);
bb = chop_H(b,opt);
bx = chop_H(x0,opt);
xec = chop_H(xex,opt); % "exact solution"

% r = bb - bA .* bx; % initial residual vector
r = chop_H(bb - chop_H(bA * bx,opt),opt);

errn = zeros(1,nitmax+1); % double precision values
errnl2 = zeros(1,nitmax+1);
resn = zeros(1,nitmax+1);
resnt = zeros(1,nitmax+1);
err = chop_H(bx - xec,opt); % initial error

er = chop_H(err' * chop_H(bA * err,opt),opt); 
errn(1) = sqrt(er); % A-norm of the error
errnl2(1) = sqrt(chop_H(err' * err,opt));

% res = r' * r; 
res = chop_H(r' * r,opt);

resn(1) = sqrt(res);
resnt(1) = resn(1);
nr = resn(1);

p = r;
rtr = res;

% dbb = bb' * bb; 
dbb = chop_H(bb' * bb,opt); 
nb = sqrt(dbb);

nit = 0;

while (nit < nitmax) && (nr > epsi * nb)
 nit = nit + 1;
%  fprintf(' iteration %d \n',nit)
 Ap = chop_H(bA * p,opt); %  Ap = bA * p that is, Ap = A * p
 
 pAp = chop_H(p' * Ap,opt); %  pAp = p' * Ap; 
   
 alp = chop_H(rtr / pAp,opt); %  alp = rtr / pAp;
  
 bx = chop_H(bx + chop_H(alp * p,opt),opt); %  bx = bx + alp * p;
 
 r = chop_H(r - chop_H(alp * Ap,opt),opt); %  r = r - alp * Ap;
 
%  if nit >=1
%   alp
%   r'
%  end
 
 rk = chop_H(r' * r,opt); %  rk = r' * r;

 err = chop_H(bx - xec,opt); %  err = bx - xec,   error
 er = chop_H(err' * chop_H(bA * err,opt),opt); %  er = err' * (bA .* err); 
 errn(nit+1) = sqrt(er); % A-norm of the error
 errnl2(nit+1) = sqrt(chop_H(err' * err,opt));
 
 res = rk; 
 
 resn(nit+1) = sqrt(res);

 rt = chop_H(bb - chop_H(bA * bx,opt),opt); %  rt = bb - bA .* bx,   "true" residual
 
 res = chop_H(rt' * rt,opt); %  res = rt' * rt; 
 resnt(nit+1) = sqrt(res);
 
 bet = chop_H(rk / rtr,opt); %  bet = rk / rtr;
  
 rtr = rk;
 
 p = chop_H(r + chop_H(bet * p,opt),opt); %  p = r + bet * p;
 
end % while

x = bx;


