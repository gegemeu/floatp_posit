function [x,resn,resnt,errn,errnl2,nit]=cg_fix_diag(A,b,x0,xex,epsi,nitmax,nbits);
%CG_FIX_DIAG CG for a diagonal matrix A of fixed point binary numbers 

% A must be a vector (diag of the matrix)
% b rhs, x0 initial vector
% xex = "exact" solution
% epsi = stopping criterion threshold
% nitmax  = number of iterations
% nbits = size of the significand (fractional part)

% the inputs are double precision numbers

%
% Author G. Meurant
% April 2020
%  


% convert inputs to posits
bA = fixp(A,nbits);
bb = fixp(b,nbits);
bx = fixp(x0,nbits);
xec = fixp(xex,nbits); % "exact solution"

r = minus_binfm(bb,mul_binfm(bA,bx)); % initial residual vector

errn = zeros(1,nitmax+1); % double precision values
errnl2 = zeros(1,nitmax+1);
resn = zeros(1,nitmax+1);
resnt = zeros(1,nitmax+1);
err = minus_binfm(bx,xec); % initial error

er = dot_binf(err,mul_binfm(bA,err));
errn(1) = sqrt(binf2dec(er)); 

er = dot_binf(err,err);
errnl2(1) = sqrt(binf2dec(er));

res = dot_binf(r,r);

resn(1) = sqrt(binf2dec(res)); 
resnt(1) = resn(1);
nr = resn(1);

p = r;
rtr = res;
dbb = dot_binf(bb,bb);
nb = sqrt(binf2dec(dbb));
nit = 0;

while (nit < nitmax) && (nr > epsi * nb)
 nit = nit + 1;
 fprintf(' iteration %d \n',nit)
 Ap = mul_binfm(bA,p); % Ap = A * p
 
 pAp = dot_binf(p,Ap); % pAp = p' * Ap

 
 [alp,flag] = div_binf(rtr,pAp); % alp = rtr / pAp 
 
 if double(alp) == 0
  error(' alp = 0, stagnation of CG')
 end % if
 
 if flag == 1
  x = binf2decm(bx);
  resn = resn(1:nit);
  resnt = resnt(1:nit);
  errn = errn(1:nit);
  return
 end % if
 
%  dalp = p_binf2decm(alp)
 
%  alp
%  p_binf2decm(rtr) / p_binf2decm(pAp)
 
 bx = add_binfm(bx,mul_binfsm(alp,p)); % x = x + alp * p
 
 r = minus_binfm(r,mul_binfsm(alp,Ap)); % r = r- alp * Ap 
 
 rk = dot_binf(r,r); % rk = r' * r

 err = minus_binfm(bx,xec); % error
 er = dot_binf(err,mul_binfm(bA,err));
 errn(nit+1) = sqrt(binf2dec(er)); % norm of the error
 
 er = dot_binf(err,err);
 errnl2(nit+11) = sqrt(binf2dec(er));
 
 res = dot_binf(r,r);
 
 resn(nit+1) = sqrt(binf2dec(res)); % norm of the computed residual

 rt = minus_binfm(bb,mul_binfm(bA,bx));
 
 res = dot_binf(rt,rt);
 
 resnt(nit+1) = sqrt(binf2dec(res)); % norm of the true residual

 [bet,flag] = div_binf(rk,rtr); % bet = rk / rtr
 
  if flag == 1
  x = binf2decm(bx);
  resn = resn(1:nit+1);
  resnt = resnt(1:nit+1);
  errn = errn(1:nit+1);
  return
 end
 
%  dbet = p_binf2decm(bet)
 
 rtr = rk;
 
 p = add_binfm(r,mul_binfsm(bet,p)); % p = r + bet * p 
 
end % while

x = binf2decm(bx);


