function [x,resn,resnt,errn,errnl2,nit]=cg_A(A,b,x0,xec,epsi,nitmax,rounding);
%CG_A CG for Ax = b

% double precision

% no preconditioning

% A = matrix
% b = rhs, x0 = initial vector
% xex = "exact" solution
% epsi = stopping criterion threshold
% nitmax  = number of iterations
% rounding = rounding mode

%
% Author G. Meurant
% May 2020
%  

if nargin > 6
 switch rounding
  case 1
   feature('SetRound',0.5); % (default) round to nearest, ties??
  case 2
   feature('SetRound',Inf); % round to +Inf
  case 3
   feature('SetRound',-Inf); % round to -Inf
  case 4
   feature('SetRound',0); % round to 0
  otherwise
   error(' cg_diag: rounding mode not available')
 end % switch
end % if

r = b - A * x0; % initial residual vector
errn = zeros(1,nitmax+1);
errnl2 = zeros(1,nitmax+1);
resn = zeros(1,nitmax+1);
resnt = zeros(1,nitmax+1);
err = x0 - xec; % initial error
x = x0;
errn(1) = sqrt(err' * (A * err));
errnl2(1) = sqrt(err' * err);
res = r' * r;
resn(1) = norm(r);
resnt(1) = resn(1);
nr = resn(1);
p = r;
rtr = res;
nb = norm(b);
nit = 0;

while (nit < nitmax) && (nr > epsi * nb)
 nit = nit + 1;
 
 Ap = A * p; % Ap = A * p
 
 pAp = p' * Ap;
 alp = rtr / pAp;
 
 x = x + alp * p;
 r = r- alp * Ap;
 
 rk = r' * r;
 
 err = x - xec; % error
 errn(nit+1) = sqrt(err' * (A * err)); % A-norm of the error
 errnl2(nit+1) = sqrt(err' * err);
 resn(nit+1) = norm(r); % norm of the computed residual
 rt = b - A * x;
 resnt(nit+1) = norm(rt); % norm of the true residual

 bet = rk / rtr;
 
 rtr = rk;
 
 p = r + bet * p;
 
end % while



