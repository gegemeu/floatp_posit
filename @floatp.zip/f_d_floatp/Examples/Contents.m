% EXAMPLES
%
% Files
%   cg_A                 - CG for Ax = b
%   cg_chop_diag         - CG for a diagonal matrix A 
%   cg_chop_H_A          - CG for a matrix A
%   cg_chop_H_diag       - CG for a diagonal matrix A of chop numbers 
%   cg_diag              - CG for a diagonal matrix A stored as a vector
%   cg_f_d_floatp_A      - CG for a matrix A of floating point binary numbers
%   cg_f_d_floatp_A_q    - CG for a matrix A of floating point binary numbers
%   cg_f_d_floatp_diag   - CG for a diagonal matrix A of floating point binary numbers
%   cg_f_d_floatp_diag_q - CG for a diagonal matrix A of floating point binary numbers with a quire
%   cg_fix_diag          - CG for a diagonal matrix A of fixed point binary numbers 
%   cg_floatp_diag       - CG for a diagonal matrix A of floating point binary numbers 
%   cg_single_A          - CG for A x = b
%   cg_single_diag       - CG for a diagonal matrix A 

% strakos_diag_30 contains a diagonal matrix of order 30 stored as a vector

% bcsstk01_float contains another example stored as a full matrix of order 48, even
% though the matrix is sparse