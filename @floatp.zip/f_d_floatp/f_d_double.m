function dec=f_d_double(fa);
%F_D_DOUBLE decimal value of fa

%
% Author G. Meurant
% May 2020
%

dec = fa.float;

